# 🍽 Spice Garden — Restaurant Ordering App

[![GitHub](https://img.shields.io/badge/GitHub-Gyanendra98180-181717?style=flat&logo=github)](https://github.com/Gyanendra98180/spicegarden)
[![Next.js](https://img.shields.io/badge/Next.js-14-black?style=flat&logo=next.js)](https://nextjs.org)
[![Node.js](https://img.shields.io/badge/Node.js-20-green?style=flat&logo=node.js)](https://nodejs.org)
[![PostgreSQL](https://img.shields.io/badge/PostgreSQL-15-blue?style=flat&logo=postgresql)](https://postgresql.org)

> A complete, production-ready restaurant web & mobile app — by [Gyanendra98180](https://github.com/Gyanendra98180)

## 🚀 Quick Start

```bash
git clone https://github.com/Gyanendra98180/spicegarden.git
cd spicegarden
cp backend/.env.example backend/.env
docker-compose up --build
# App → http://localhost:3000
```

## ✨ Features
- 🔐 Auth: Email, Phone, OTP (Twilio + Nodemailer)
- 🍽 Menu with search, filters, ratings
- 🛒 Persistent cart with Zustand
- 🏷 Coupon codes (WELCOME20, SPICE10, FREEDEL)
- 💳 Razorpay: UPI, Cards, Wallets, COD
- 📍 Real-time order tracking via Socket.io
- 🔔 Push notifications (Firebase FCM)
- 👨‍💼 Admin dashboard: live orders, stats, menu
- 📱 PWA — installable on mobile
- 🐳 Docker Compose for local dev

## 🔑 Demo Credentials
| Role | Email | Password |
|------|-------|----------|
| Admin | admin@spicegarden.in | Admin@123 |
| Customer | customer@demo.com | Demo@123 |

## 📦 Push to GitHub
```bash
git remote add origin https://github.com/Gyanendra98180/spicegarden.git
git branch -M main
git push -u origin main
```

## 📚 Docs
- [Setup Guide](docs/SETUP.md)
- [API Reference](docs/API.md)

Made with ❤️ by [Gyanendra98180](https://github.com/Gyanendra98180)
