require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');

const authRoutes     = require('./routes/auth');
const menuRoutes     = require('./routes/menu');
const orderRoutes    = require('./routes/orders');
const paymentRoutes  = require('./routes/payments');
const addressRoutes  = require('./routes/addresses');
const couponRoutes   = require('./routes/coupons');
const reviewRoutes   = require('./routes/reviews');
const adminRoutes    = require('./routes/admin');
const uploadRoutes   = require('./routes/uploads');
const { errorHandler } = require('./middleware/errorHandler');
const { socketAuth }   = require('./middleware/socketAuth');

const app    = express();
const server = http.createServer(app);
const io     = new Server(server, {
  cors: { origin: process.env.FRONTEND_URL, credentials: true }
});

// Attach io to app so routes can emit
app.set('io', io);

// ── Security & Parsing ──────────────────────────────
app.use(helmet());
app.use(cors({ origin: process.env.FRONTEND_URL, credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(morgan('dev'));

// ── Rate Limiting ───────────────────────────────────
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, max: 20, message: 'Too many requests' }));
app.use('/api',      rateLimit({ windowMs: 60 * 1000, max: 200 }));

// ── Routes ──────────────────────────────────────────
app.use('/api/auth',      authRoutes);
app.use('/api/menu',      menuRoutes);
app.use('/api/orders',    orderRoutes);
app.use('/api/payments',  paymentRoutes);
app.use('/api/addresses', addressRoutes);
app.use('/api/coupons',   couponRoutes);
app.use('/api/reviews',   reviewRoutes);
app.use('/api/admin',     adminRoutes);
app.use('/api/uploads',   uploadRoutes);

app.get('/api/health', (_req, res) => res.json({ status: 'ok', time: new Date() }));

// ── Socket.io ───────────────────────────────────────
io.use(socketAuth);
io.on('connection', (socket) => {
  const userId = socket.handshake.auth.userId;
  if (userId) socket.join(`user:${userId}`);

  socket.on('join_order', (orderId) => socket.join(`order:${orderId}`));
  socket.on('disconnect', () => {});
});

// ── Error Handler ───────────────────────────────────
app.use(errorHandler);

const PORT = process.env.PORT || 4000;
server.listen(PORT, () => console.log(`🍽  Spice Garden API running on port ${PORT}`));

module.exports = { app, io };
