// ── middleware/socketAuth.js ──────────────────────────────────
const jwt = require('jsonwebtoken');

function socketAuth(socket, next) {
  const token = socket.handshake.auth?.token;
  if (token) {
    try {
      socket.user = jwt.verify(token, process.env.JWT_SECRET);
      socket.handshake.auth.userId = socket.user.sub;
    } catch {}
  }
  next();
}

module.exports = { socketAuth };
