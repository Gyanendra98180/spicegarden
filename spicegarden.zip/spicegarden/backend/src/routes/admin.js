const router = require('express').Router();
const { query } = require('../utils/db');
const { authenticate, requireRole } = require('../middleware/auth');

const adminOnly = [authenticate, requireRole('admin')];

// GET /api/admin/dashboard
router.get('/dashboard', ...adminOnly, async (req, res, next) => {
  try {
    const today = new Date().toISOString().split('T')[0];

    const [revenue, activeOrders, newCustomers, topItems] = await Promise.all([
      query(`SELECT COALESCE(SUM(total_amount),0) AS total, COUNT(*) AS count
             FROM orders WHERE DATE(created_at)=$1 AND status != 'cancelled'`, [today]),
      query(`SELECT status, COUNT(*) AS count FROM orders
             WHERE status IN ('confirmed','preparing','out_for_delivery') GROUP BY status`),
      query(`SELECT COUNT(*) FROM users WHERE DATE(created_at)=$1`, [today]),
      query(`SELECT m.name, m.emoji, SUM(oi.quantity) AS qty, SUM(oi.line_total) AS revenue
             FROM order_items oi
             JOIN menu_items m ON m.id=oi.item_id
             JOIN orders o ON o.id=oi.order_id
             WHERE DATE(o.created_at)=$1 AND o.status != 'cancelled'
             GROUP BY m.id ORDER BY qty DESC LIMIT 5`, [today]),
    ]);

    res.json({
      today_revenue:  Number(revenue.rows[0].total),
      today_orders:   Number(revenue.rows[0].count),
      active_orders:  activeOrders.rows,
      new_customers:  Number(newCustomers.rows[0].count),
      top_items:      topItems.rows,
    });
  } catch (err) { next(err); }
});

// GET /api/admin/reports?from=2024-01-01&to=2024-01-31
router.get('/reports', ...adminOnly, async (req, res, next) => {
  try {
    const { from, to } = req.query;
    const { rows } = await query(
      `SELECT DATE(created_at) AS date,
              COUNT(*) FILTER (WHERE status != 'cancelled') AS orders,
              COALESCE(SUM(total_amount) FILTER (WHERE status != 'cancelled'), 0) AS revenue,
              COALESCE(SUM(discount_amount) FILTER (WHERE status != 'cancelled'), 0) AS discount,
              COUNT(*) FILTER (WHERE status = 'cancelled') AS cancellations
       FROM orders
       WHERE created_at BETWEEN $1 AND $2
       GROUP BY DATE(created_at) ORDER BY date ASC`,
      [from || '2024-01-01', to || new Date().toISOString()]
    );
    res.json(rows);
  } catch (err) { next(err); }
});

// GET /api/admin/orders
router.get('/orders', ...adminOnly, async (req, res, next) => {
  try {
    const { status, page = 1, limit = 20 } = req.query;
    let where = 'WHERE 1=1';
    const params = [];
    let i = 1;
    if (status) { where += ` AND o.status=$${i++}`; params.push(status); }

    const { rows } = await query(
      `SELECT o.*, COALESCE(u.name, o.guest_name) AS customer_name,
              COALESCE(u.phone, o.guest_phone) AS customer_phone,
              p.status AS payment_status, COUNT(oi.id) AS item_count
       FROM orders o
       LEFT JOIN users u ON o.user_id=u.id
       LEFT JOIN payments p ON p.order_id=o.id
       LEFT JOIN order_items oi ON oi.order_id=o.id
       ${where} GROUP BY o.id, u.name, u.phone, p.status
       ORDER BY o.created_at DESC
       LIMIT $${i} OFFSET $${i + 1}`,
      [...params, limit, (Number(page) - 1) * Number(limit)]
    );
    res.json(rows);
  } catch (err) { next(err); }
});

// GET /api/admin/users
router.get('/users', ...adminOnly, async (req, res, next) => {
  try {
    const { rows } = await query(
      `SELECT u.id, u.name, u.email, u.phone, u.role, u.is_verified, u.created_at,
              COUNT(o.id) AS order_count, COALESCE(SUM(o.total_amount),0) AS total_spent
       FROM users u
       LEFT JOIN orders o ON o.user_id=u.id AND o.status != 'cancelled'
       WHERE u.role='customer'
       GROUP BY u.id ORDER BY u.created_at DESC LIMIT 100`
    );
    res.json(rows);
  } catch (err) { next(err); }
});

module.exports = router;
