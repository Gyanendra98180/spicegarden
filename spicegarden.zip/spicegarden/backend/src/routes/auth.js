const router  = require('express').Router();
const bcrypt  = require('bcryptjs');
const jwt     = require('jsonwebtoken');
const { v4: uuid } = require('uuid');
const { query }    = require('../utils/db');
const { sendOTP, sendWelcomeEmail } = require('../services/notifications');
const { authenticate } = require('../middleware/auth');
const { z } = require('zod');

// ── Helpers ──────────────────────────────────────────────────

function signAccess(user) {
  return jwt.sign(
    { sub: user.id, role: user.role, name: user.name },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '15m' }
  );
}

function signRefresh(user) {
  return jwt.sign(
    { sub: user.id },
    process.env.JWT_REFRESH_SECRET,
    { expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '30d' }
  );
}

async function storeRefreshToken(userId, token) {
  const hash = require('crypto').createHash('sha256').update(token).digest('hex');
  const expires = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
  await query(
    `INSERT INTO refresh_tokens (user_id, token_hash, expires_at) VALUES ($1,$2,$3)`,
    [userId, hash, expires]
  );
}

// ── POST /api/auth/signup ─────────────────────────────────────

router.post('/signup', async (req, res, next) => {
  try {
    const schema = z.object({
      name:     z.string().min(2).max(100),
      email:    z.string().email().optional(),
      phone:    z.string().regex(/^\+?[0-9]{10,15}$/).optional(),
      password: z.string().min(6),
    }).refine(d => d.email || d.phone, { message: 'Email or phone required' });

    const { name, email, phone, password } = schema.parse(req.body);

    if (email) {
      const { rows } = await query('SELECT id FROM users WHERE email=$1', [email]);
      if (rows.length) return res.status(409).json({ error: 'Email already registered' });
    }
    if (phone) {
      const { rows } = await query('SELECT id FROM users WHERE phone=$1', [phone]);
      if (rows.length) return res.status(409).json({ error: 'Phone already registered' });
    }

    const password_hash = await bcrypt.hash(password, 12);
    const { rows } = await query(
      `INSERT INTO users (name, email, phone, password_hash) VALUES ($1,$2,$3,$4) RETURNING id, name, email, phone, role`,
      [name, email || null, phone || null, password_hash]
    );

    const user = rows[0];
    if (email) await sendWelcomeEmail(email, name).catch(() => {});

    const access  = signAccess(user);
    const refresh = signRefresh(user);
    await storeRefreshToken(user.id, refresh);

    res.status(201).json({ user, access_token: access, refresh_token: refresh });
  } catch (err) { next(err); }
});

// ── POST /api/auth/login ─────────────────────────────────────

router.post('/login', async (req, res, next) => {
  try {
    const { identifier, password } = req.body;
    if (!identifier || !password) return res.status(400).json({ error: 'identifier and password required' });

    const isEmail = identifier.includes('@');
    const col = isEmail ? 'email' : 'phone';
    const { rows } = await query(`SELECT * FROM users WHERE ${col}=$1 AND is_active=TRUE`, [identifier]);
    if (!rows.length) return res.status(401).json({ error: 'Invalid credentials' });

    const user = rows[0];
    const ok   = await bcrypt.compare(password, user.password_hash);
    if (!ok) return res.status(401).json({ error: 'Invalid credentials' });

    const access  = signAccess(user);
    const refresh = signRefresh(user);
    await storeRefreshToken(user.id, refresh);

    const { password_hash, ...safe } = user;
    res.json({ user: safe, access_token: access, refresh_token: refresh });
  } catch (err) { next(err); }
});

// ── POST /api/auth/send-otp ──────────────────────────────────

router.post('/send-otp', async (req, res, next) => {
  try {
    const { target, purpose = 'login' } = req.body;
    if (!target) return res.status(400).json({ error: 'target required' });

    const code = String(Math.floor(100000 + Math.random() * 900000));
    const expires = new Date(Date.now() + 10 * 60 * 1000); // 10 min

    await query(
      `INSERT INTO otp_codes (target, code, purpose, expires_at) VALUES ($1,$2,$3,$4)`,
      [target, code, purpose, expires]
    );

    await sendOTP(target, code);
    res.json({ message: 'OTP sent', expires_at: expires });
  } catch (err) { next(err); }
});

// ── POST /api/auth/verify-otp ────────────────────────────────

router.post('/verify-otp', async (req, res, next) => {
  try {
    const { target, code, name } = req.body;
    if (!target || !code) return res.status(400).json({ error: 'target and code required' });

    const { rows } = await query(
      `SELECT * FROM otp_codes WHERE target=$1 AND code=$2 AND used=FALSE AND expires_at > NOW() ORDER BY created_at DESC LIMIT 1`,
      [target, code]
    );
    if (!rows.length) return res.status(400).json({ error: 'Invalid or expired OTP' });

    await query('UPDATE otp_codes SET used=TRUE WHERE id=$1', [rows[0].id]);

    const isEmail = target.includes('@');
    const col     = isEmail ? 'email' : 'phone';

    let { rows: users } = await query(`SELECT * FROM users WHERE ${col}=$1`, [target]);
    let user;
    if (!users.length) {
      const { rows: created } = await query(
        `INSERT INTO users (name, ${col}, is_verified) VALUES ($1,$2,TRUE) RETURNING *`,
        [name || 'User', target]
      );
      user = created[0];
    } else {
      await query(`UPDATE users SET is_verified=TRUE WHERE id=$1`, [users[0].id]);
      user = { ...users[0], is_verified: true };
    }

    const access  = signAccess(user);
    const refresh = signRefresh(user);
    await storeRefreshToken(user.id, refresh);

    const { password_hash, ...safe } = user;
    res.json({ user: safe, access_token: access, refresh_token: refresh });
  } catch (err) { next(err); }
});

// ── POST /api/auth/refresh ────────────────────────────────────

router.post('/refresh', async (req, res, next) => {
  try {
    const { refresh_token } = req.body;
    if (!refresh_token) return res.status(400).json({ error: 'refresh_token required' });

    let payload;
    try { payload = jwt.verify(refresh_token, process.env.JWT_REFRESH_SECRET); }
    catch { return res.status(401).json({ error: 'Invalid or expired refresh token' }); }

    const hash = require('crypto').createHash('sha256').update(refresh_token).digest('hex');
    const { rows } = await query(
      `SELECT * FROM refresh_tokens WHERE user_id=$1 AND token_hash=$2 AND revoked=FALSE AND expires_at > NOW()`,
      [payload.sub, hash]
    );
    if (!rows.length) return res.status(401).json({ error: 'Refresh token revoked or expired' });

    const { rows: users } = await query('SELECT * FROM users WHERE id=$1 AND is_active=TRUE', [payload.sub]);
    if (!users.length) return res.status(401).json({ error: 'User not found' });

    const access = signAccess(users[0]);
    res.json({ access_token: access });
  } catch (err) { next(err); }
});

// ── POST /api/auth/logout ────────────────────────────────────

router.post('/logout', authenticate, async (req, res, next) => {
  try {
    const { refresh_token } = req.body;
    if (refresh_token) {
      const hash = require('crypto').createHash('sha256').update(refresh_token).digest('hex');
      await query('UPDATE refresh_tokens SET revoked=TRUE WHERE token_hash=$1', [hash]);
    }
    res.json({ message: 'Logged out' });
  } catch (err) { next(err); }
});

// ── GET /api/auth/me ─────────────────────────────────────────

router.get('/me', authenticate, async (req, res, next) => {
  try {
    const { rows } = await query(
      `SELECT id, name, email, phone, role, avatar_url, is_verified, created_at FROM users WHERE id=$1`,
      [req.user.sub]
    );
    if (!rows.length) return res.status(404).json({ error: 'User not found' });
    res.json(rows[0]);
  } catch (err) { next(err); }
});

// ── PATCH /api/auth/me ───────────────────────────────────────

router.patch('/me', authenticate, async (req, res, next) => {
  try {
    const { name, avatar_url } = req.body;
    const { rows } = await query(
      `UPDATE users SET name=COALESCE($1,name), avatar_url=COALESCE($2,avatar_url)
       WHERE id=$3 RETURNING id, name, email, phone, role, avatar_url`,
      [name, avatar_url, req.user.sub]
    );
    res.json(rows[0]);
  } catch (err) { next(err); }
});

module.exports = router;
