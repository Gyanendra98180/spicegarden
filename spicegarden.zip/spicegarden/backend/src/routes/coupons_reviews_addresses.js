// ── routes/coupons.js ─────────────────────────────────────────
const router = require('express').Router();
const { query } = require('../utils/db');
const { optionalAuth, authenticate, requireRole } = require('../middleware/auth');

// POST /api/coupons/validate
router.post('/validate', optionalAuth, async (req, res, next) => {
  try {
    const { code, amount } = req.body;
    if (!code || !amount) return res.status(400).json({ error: 'code and amount required' });

    const { rows } = await query(
      `SELECT * FROM coupons
       WHERE code=$1 AND is_active=TRUE
         AND (valid_until IS NULL OR valid_until > NOW())
         AND (usage_limit IS NULL OR usage_count < usage_limit)
         AND min_order_amount <= $2`,
      [code.toUpperCase(), amount]
    );

    if (!rows.length) return res.status(400).json({ error: 'Invalid or expired coupon' });

    const c = rows[0];
    let discount = 0;
    if (c.type === 'percent')       discount = Math.min(amount * c.value / 100, c.max_discount || Infinity);
    else if (c.type === 'flat')     discount = Math.min(c.value, amount);
    else if (c.type === 'free_delivery') discount = 40;

    res.json({ code: c.code, type: c.type, value: Number(c.value), discount: Math.round(discount * 100) / 100, description: c.description });
  } catch (err) { next(err); }
});

// GET /api/coupons (admin)
router.get('/', authenticate, requireRole('admin'), async (req, res, next) => {
  try {
    const { rows } = await query('SELECT * FROM coupons ORDER BY created_at DESC');
    res.json(rows);
  } catch (err) { next(err); }
});

// POST /api/coupons (admin)
router.post('/', authenticate, requireRole('admin'), async (req, res, next) => {
  try {
    const { code, description, type, value, min_order_amount, max_discount, usage_limit, valid_until } = req.body;
    const { rows } = await query(
      `INSERT INTO coupons (code, description, type, value, min_order_amount, max_discount, usage_limit, valid_until)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [code.toUpperCase(), description, type, value, min_order_amount || 0, max_discount, usage_limit, valid_until]
    );
    res.status(201).json(rows[0]);
  } catch (err) { next(err); }
});

module.exports = router;

// ── routes/reviews.js ─────────────────────────────────────────
const reviewRouter = require('express').Router();

reviewRouter.post('/', authenticate, async (req, res, next) => {
  try {
    const { order_id, item_id, rating, comment } = req.body;
    if (!order_id || !rating) return res.status(400).json({ error: 'order_id and rating required' });
    if (rating < 1 || rating > 5) return res.status(400).json({ error: 'Rating must be 1-5' });

    // Verify user owns the order
    const { rows: orders } = await query('SELECT id FROM orders WHERE id=$1 AND user_id=$2', [order_id, req.user.sub]);
    if (!orders.length) return res.status(403).json({ error: 'Cannot review this order' });

    const { rows } = await query(
      `INSERT INTO reviews (user_id, order_id, item_id, rating, comment) VALUES ($1,$2,$3,$4,$5)
       ON CONFLICT DO NOTHING RETURNING *`,
      [req.user.sub, order_id, item_id || null, rating, comment]
    );
    res.status(201).json(rows[0] || { message: 'Already reviewed' });
  } catch (err) { next(err); }
});

reviewRouter.get('/', async (req, res, next) => {
  try {
    const { item_id, limit = 10 } = req.query;
    let where = 'WHERE r.is_visible=TRUE';
    const params = [];
    if (item_id) { where += ` AND r.item_id=$1`; params.push(item_id); }

    const { rows } = await query(
      `SELECT r.*, u.name AS user_name, u.avatar_url
       FROM reviews r JOIN users u ON r.user_id=u.id
       ${where} ORDER BY r.created_at DESC LIMIT $${params.length + 1}`,
      [...params, limit]
    );
    res.json(rows);
  } catch (err) { next(err); }
});

module.exports = { couponRouter: router, reviewRouter };

// ── routes/addresses.js ───────────────────────────────────────
const addrRouter = require('express').Router();

addrRouter.get('/', authenticate, async (req, res, next) => {
  try {
    const { rows } = await query('SELECT * FROM addresses WHERE user_id=$1 ORDER BY is_default DESC, created_at DESC', [req.user.sub]);
    res.json(rows);
  } catch (err) { next(err); }
});

addrRouter.post('/', authenticate, async (req, res, next) => {
  try {
    const { label, line1, line2, city, state, pincode, lat, lng, is_default } = req.body;
    if (is_default) await query('UPDATE addresses SET is_default=FALSE WHERE user_id=$1', [req.user.sub]);
    const { rows } = await query(
      `INSERT INTO addresses (user_id, label, line1, line2, city, state, pincode, lat, lng, is_default)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`,
      [req.user.sub, label, line1, line2, city, state, pincode, lat, lng, is_default || false]
    );
    res.status(201).json(rows[0]);
  } catch (err) { next(err); }
});

addrRouter.patch('/:id', authenticate, async (req, res, next) => {
  try {
    const { label, line1, line2, city, state, pincode, is_default } = req.body;
    if (is_default) await query('UPDATE addresses SET is_default=FALSE WHERE user_id=$1', [req.user.sub]);
    const { rows } = await query(
      `UPDATE addresses SET label=$1,line1=$2,line2=$3,city=$4,state=$5,pincode=$6,is_default=$7
       WHERE id=$8 AND user_id=$9 RETURNING *`,
      [label, line1, line2, city, state, pincode, is_default || false, req.params.id, req.user.sub]
    );
    if (!rows.length) return res.status(404).json({ error: 'Address not found' });
    res.json(rows[0]);
  } catch (err) { next(err); }
});

addrRouter.delete('/:id', authenticate, async (req, res, next) => {
  try {
    await query('DELETE FROM addresses WHERE id=$1 AND user_id=$2', [req.params.id, req.user.sub]);
    res.json({ message: 'Deleted' });
  } catch (err) { next(err); }
});

module.exports = { addrRouter };
