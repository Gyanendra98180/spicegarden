const router = require('express').Router();
const { query } = require('../utils/db');
const { authenticate, requireRole } = require('../middleware/auth');

// GET /api/menu/categories
router.get('/categories', async (req, res, next) => {
  try {
    const { rows } = await query(
      `SELECT c.*, COUNT(m.id) FILTER (WHERE m.is_available) AS item_count
       FROM categories c
       LEFT JOIN menu_items m ON m.category_id = c.id
       WHERE c.is_active = TRUE
       GROUP BY c.id ORDER BY c.sort_order`
    );
    res.json(rows);
  } catch (err) { next(err); }
});

// GET /api/menu/items
router.get('/items', async (req, res, next) => {
  try {
    const { category, search, veg, featured, page = 1, limit = 50 } = req.query;
    let conditions = ['m.is_available = TRUE'];
    let params = [];
    let i = 1;

    if (category) { conditions.push(`c.slug = $${i++}`); params.push(category); }
    if (search)   { conditions.push(`(m.name ILIKE $${i} OR m.description ILIKE $${i})`); params.push(`%${search}%`); i++; }
    if (veg === 'true') { conditions.push(`m.is_veg = TRUE`); }
    if (featured === 'true') { conditions.push(`m.is_featured = TRUE`); }

    const offset = (Number(page) - 1) * Number(limit);
    const where  = conditions.length ? 'WHERE ' + conditions.join(' AND ') : '';

    const { rows } = await query(
      `SELECT m.*, c.name AS category_name, c.slug AS category_slug,
              ROUND(AVG(r.rating)::NUMERIC, 1) AS avg_rating,
              COUNT(r.id) AS review_count
       FROM menu_items m
       JOIN categories c ON m.category_id = c.id
       LEFT JOIN reviews r ON r.item_id = m.id AND r.is_visible = TRUE
       ${where}
       GROUP BY m.id, c.name, c.slug
       ORDER BY m.is_featured DESC, m.sort_order, m.name
       LIMIT $${i} OFFSET $${i + 1}`,
      [...params, limit, offset]
    );

    const { rows: countRows } = await query(
      `SELECT COUNT(DISTINCT m.id) FROM menu_items m JOIN categories c ON m.category_id=c.id ${where}`,
      params
    );

    res.json({ items: rows, total: Number(countRows[0].count), page: Number(page), limit: Number(limit) });
  } catch (err) { next(err); }
});

// GET /api/menu/items/:slug
router.get('/items/:slug', async (req, res, next) => {
  try {
    const { rows } = await query(
      `SELECT m.*, c.name AS category_name,
              ROUND(AVG(r.rating)::NUMERIC, 1) AS avg_rating,
              COUNT(r.id) AS review_count
       FROM menu_items m
       JOIN categories c ON m.category_id = c.id
       LEFT JOIN reviews r ON r.item_id = m.id AND r.is_visible = TRUE
       WHERE m.slug = $1
       GROUP BY m.id, c.name`,
      [req.params.slug]
    );
    if (!rows.length) return res.status(404).json({ error: 'Item not found' });

    const { rows: reviews } = await query(
      `SELECT r.*, u.name AS user_name, u.avatar_url FROM reviews r
       JOIN users u ON r.user_id = u.id
       WHERE r.item_id = $1 AND r.is_visible = TRUE
       ORDER BY r.created_at DESC LIMIT 10`,
      [rows[0].id]
    );

    res.json({ ...rows[0], reviews });
  } catch (err) { next(err); }
});

// ── Admin: POST /api/menu/items ───────────────────────────────
router.post('/items', authenticate, requireRole('admin'), async (req, res, next) => {
  try {
    const {
      category_id, name, slug, description, price, compare_price,
      image_url, emoji, is_veg = true, spice_level = 0,
      prep_time_mins, is_featured = false, tags = []
    } = req.body;

    const { rows } = await query(
      `INSERT INTO menu_items
         (category_id, name, slug, description, price, compare_price,
          image_url, emoji, is_veg, spice_level, prep_time_mins, is_featured, tags)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) RETURNING *`,
      [category_id, name, slug, description, price, compare_price,
       image_url, emoji, is_veg, spice_level, prep_time_mins, is_featured, tags]
    );
    res.status(201).json(rows[0]);
  } catch (err) { next(err); }
});

// ── Admin: PATCH /api/menu/items/:id ─────────────────────────
router.patch('/items/:id', authenticate, requireRole('admin'), async (req, res, next) => {
  try {
    const fields = ['name','description','price','compare_price','image_url','emoji',
                    'is_veg','spice_level','prep_time_mins','is_featured','is_available',
                    'category_id','sort_order','tags'];
    const updates = [];
    const params  = [];
    let i = 1;

    fields.forEach(f => {
      if (req.body[f] !== undefined) {
        updates.push(`${f} = $${i++}`);
        params.push(req.body[f]);
      }
    });

    if (!updates.length) return res.status(400).json({ error: 'No fields to update' });
    params.push(req.params.id);

    const { rows } = await query(
      `UPDATE menu_items SET ${updates.join(', ')} WHERE id = $${i} RETURNING *`,
      params
    );
    if (!rows.length) return res.status(404).json({ error: 'Item not found' });
    res.json(rows[0]);
  } catch (err) { next(err); }
});

// ── Admin: DELETE /api/menu/items/:id ────────────────────────
router.delete('/items/:id', authenticate, requireRole('admin'), async (req, res, next) => {
  try {
    await query('UPDATE menu_items SET is_available=FALSE WHERE id=$1', [req.params.id]);
    res.json({ message: 'Item deactivated' });
  } catch (err) { next(err); }
});

module.exports = router;
