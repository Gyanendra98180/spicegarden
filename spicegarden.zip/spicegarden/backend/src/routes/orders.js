const router = require('express').Router();
const { query, getClient } = require('../utils/db');
const { authenticate, optionalAuth, requireRole } = require('../middleware/auth');
const { sendOrderConfirmation, sendPushNotification } = require('../services/notifications');

// ── POST /api/orders ─────────────────────────────────────────
router.post('/', optionalAuth, async (req, res, next) => {
  const client = await getClient();
  try {
    await client.query('BEGIN');

    const {
      items,             // [{item_id, quantity, customizations}]
      type = 'delivery',
      address_id,
      delivery_address,
      special_instructions,
      coupon_code,
      guest_name, guest_email, guest_phone,
    } = req.body;

    if (!items || !items.length) throw Object.assign(new Error('No items'), { status: 400 });

    // Fetch & validate menu items
    const itemIds = items.map(i => i.item_id);
    const { rows: menuItems } = await client.query(
      `SELECT id, name, price, image_url, emoji, is_available FROM menu_items WHERE id = ANY($1)`,
      [itemIds]
    );

    const itemMap = Object.fromEntries(menuItems.map(m => [m.id, m]));

    let subtotal = 0;
    const lineItems = items.map(({ item_id, quantity, customizations }) => {
      const mi = itemMap[item_id];
      if (!mi) throw Object.assign(new Error(`Item ${item_id} not found`), { status: 400 });
      if (!mi.is_available) throw Object.assign(new Error(`${mi.name} is unavailable`), { status: 400 });
      const line = mi.price * quantity;
      subtotal += line;
      return { item_id, quantity, unit_price: mi.price, line_total: line, customizations, snapshot: mi };
    });

    // Apply coupon
    let discount_amount = 0;
    let coupon = null;
    if (coupon_code) {
      const { rows: coupons } = await client.query(
        `SELECT * FROM coupons WHERE code=$1 AND is_active=TRUE AND (valid_until IS NULL OR valid_until > NOW())
         AND (usage_limit IS NULL OR usage_count < usage_limit) AND min_order_amount <= $2`,
        [coupon_code.toUpperCase(), subtotal]
      );
      if (!coupons.length) throw Object.assign(new Error('Invalid or expired coupon'), { status: 400 });
      coupon = coupons[0];

      if (coupon.type === 'percent') {
        discount_amount = Math.min(subtotal * coupon.value / 100, coupon.max_discount || Infinity);
      } else if (coupon.type === 'flat') {
        discount_amount = Math.min(coupon.value, subtotal);
      } else if (coupon.type === 'free_delivery') {
        discount_amount = Number(process.env.DELIVERY_FEE || 40);
      }
      discount_amount = Math.round(discount_amount * 100) / 100;
    }

    const tax_amount   = Math.round(subtotal * Number(process.env.TAX_RATE || 0.05) * 100) / 100;
    const delivery_fee = type === 'pickup' ? 0 :
      (subtotal >= Number(process.env.FREE_DELIVERY_ABOVE || 500) ? 0 : Number(process.env.DELIVERY_FEE || 40));
    const total_amount = subtotal + tax_amount + delivery_fee - discount_amount;

    // Generate order number
    const order_number = 'SG' + Date.now().toString().slice(-8);

    const { rows: [order] } = await client.query(
      `INSERT INTO orders
         (order_number, user_id, guest_name, guest_email, guest_phone, type,
          address_id, delivery_address, coupon_id, subtotal, tax_amount,
          delivery_fee, discount_amount, total_amount, special_instructions)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)
       RETURNING *`,
      [order_number,
       req.user?.sub || null,
       guest_name || null, guest_email || null, guest_phone || null,
       type, address_id || null,
       delivery_address ? JSON.stringify(delivery_address) : null,
       coupon?.id || null,
       subtotal, tax_amount, delivery_fee, discount_amount, total_amount,
       special_instructions || null]
    );

    // Insert order items
    for (const li of lineItems) {
      await client.query(
        `INSERT INTO order_items (order_id, item_id, item_snapshot, quantity, unit_price, customizations, line_total)
         VALUES ($1,$2,$3,$4,$5,$6,$7)`,
        [order.id, li.item_id, JSON.stringify(li.snapshot), li.quantity, li.unit_price,
         li.customizations ? JSON.stringify(li.customizations) : null, li.line_total]
      );
    }

    // Record status history
    await client.query(
      `INSERT INTO order_status_history (order_id, status, note) VALUES ($1,'pending','Order created')`,
      [order.id]
    );

    // Increment coupon usage
    if (coupon) {
      await client.query('UPDATE coupons SET usage_count=usage_count+1 WHERE id=$1', [coupon.id]);
      if (req.user?.sub) {
        await client.query(
          'INSERT INTO coupon_usages (coupon_id, user_id, order_id) VALUES ($1,$2,$3)',
          [coupon.id, req.user.sub, order.id]
        );
      }
    }

    await client.query('COMMIT');

    // Async side-effects
    const contact = guest_email || null;
    if (contact) sendOrderConfirmation(contact, order).catch(() => {});

    // Emit real-time to admin room
    req.app.get('io')?.to('admin').emit('new_order', { order_id: order.id, order_number, total_amount });

    res.status(201).json({ order, items: lineItems });
  } catch (err) {
    await client.query('ROLLBACK');
    next(err);
  } finally {
    client.release();
  }
});

// ── GET /api/orders ──────────────────────────────────────────
router.get('/', authenticate, async (req, res, next) => {
  try {
    const { page = 1, limit = 10, status } = req.query;
    const isAdmin = req.user.role === 'admin';

    let where = isAdmin ? 'WHERE 1=1' : 'WHERE o.user_id = $1';
    const params = isAdmin ? [] : [req.user.sub];
    let i = params.length + 1;

    if (status) { where += ` AND o.status = $${i++}`; params.push(status); }

    const offset = (Number(page) - 1) * Number(limit);
    const { rows } = await query(
      `SELECT o.*, p.status AS payment_status, p.method AS payment_method,
              COUNT(oi.id) AS item_count
       FROM orders o
       LEFT JOIN payments p ON p.order_id = o.id
       LEFT JOIN order_items oi ON oi.order_id = o.id
       ${where}
       GROUP BY o.id, p.status, p.method
       ORDER BY o.created_at DESC LIMIT $${i} OFFSET $${i + 1}`,
      [...params, limit, offset]
    );
    res.json(rows);
  } catch (err) { next(err); }
});

// ── GET /api/orders/:id ──────────────────────────────────────
router.get('/:id', optionalAuth, async (req, res, next) => {
  try {
    const { rows: [order] } = await query(
      `SELECT o.*, p.status AS payment_status, p.method AS payment_method
       FROM orders o LEFT JOIN payments p ON p.order_id=o.id WHERE o.id=$1`,
      [req.params.id]
    );
    if (!order) return res.status(404).json({ error: 'Order not found' });

    // Security: allow owner or admin or guest by order_number
    if (req.user?.role !== 'admin' && order.user_id && req.user?.sub !== order.user_id) {
      return res.status(403).json({ error: 'Forbidden' });
    }

    const { rows: items } = await query(
      `SELECT oi.*, m.emoji FROM order_items oi
       LEFT JOIN menu_items m ON m.id=oi.item_id WHERE oi.order_id=$1`,
      [order.id]
    );
    const { rows: history } = await query(
      `SELECT * FROM order_status_history WHERE order_id=$1 ORDER BY created_at ASC`,
      [order.id]
    );

    res.json({ ...order, items, history });
  } catch (err) { next(err); }
});

// ── PATCH /api/orders/:id/status (admin) ─────────────────────
router.patch('/:id/status', authenticate, requireRole('admin', 'staff'), async (req, res, next) => {
  try {
    const { status, note } = req.body;
    const valid = ['confirmed','preparing','ready','out_for_delivery','delivered','cancelled'];
    if (!valid.includes(status)) return res.status(400).json({ error: 'Invalid status' });

    const { rows: [order] } = await query(
      `UPDATE orders SET status=$1 WHERE id=$2 RETURNING *`,
      [status, req.params.id]
    );
    if (!order) return res.status(404).json({ error: 'Order not found' });

    await query(
      `INSERT INTO order_status_history (order_id, status, note, changed_by) VALUES ($1,$2,$3,$4)`,
      [order.id, status, note || null, req.user.sub]
    );

    // Push real-time update to customer
    const io = req.app.get('io');
    io?.to(`order:${order.id}`).emit('order_status', { order_id: order.id, status });
    if (order.user_id) io?.to(`user:${order.user_id}`).emit('order_status', { order_id: order.id, status });

    // Push notification
    if (order.user_id) {
      const { rows: [user] } = await query('SELECT fcm_token FROM users WHERE id=$1', [order.user_id]);
      if (user?.fcm_token) {
        sendPushNotification(user.fcm_token, `Order ${status.replace('_',' ')}`, `Your order #${order.order_number} is now ${status}`).catch(() => {});
      }
    }

    res.json(order);
  } catch (err) { next(err); }
});

module.exports = router;
