const router   = require('express').Router();
const Razorpay = require('razorpay');
const crypto   = require('crypto');
const { query } = require('../utils/db');
const { optionalAuth, authenticate } = require('../middleware/auth');

const razorpay = new Razorpay({
  key_id:     process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET,
});

// ── POST /api/payments/create-order ──────────────────────────
// Creates a Razorpay order for a given app-order
router.post('/create-order', optionalAuth, async (req, res, next) => {
  try {
    const { order_id, method } = req.body;
    if (!order_id) return res.status(400).json({ error: 'order_id required' });

    const { rows: [order] } = await query('SELECT * FROM orders WHERE id=$1', [order_id]);
    if (!order) return res.status(404).json({ error: 'Order not found' });

    const amount = Math.round(order.total_amount * 100); // paise

    const rzpOrder = await razorpay.orders.create({
      amount,
      currency: 'INR',
      receipt:  order.order_number,
      notes:    { order_id, customer_phone: order.guest_phone },
    });

    // Persist payment record
    const { rows: [payment] } = await query(
      `INSERT INTO payments (order_id, razorpay_order_id, method, amount)
       VALUES ($1,$2,$3,$4) RETURNING *`,
      [order_id, rzpOrder.id, method || 'upi', order.total_amount]
    );

    res.json({
      razorpay_order_id: rzpOrder.id,
      amount,
      currency:  'INR',
      key_id:    process.env.RAZORPAY_KEY_ID,
      payment_id: payment.id,
    });
  } catch (err) { next(err); }
});

// ── POST /api/payments/verify ─────────────────────────────────
// Verify signature after payment success on frontend
router.post('/verify', optionalAuth, async (req, res, next) => {
  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature, payment_id } = req.body;

    const expected = crypto
      .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
      .update(`${razorpay_order_id}|${razorpay_payment_id}`)
      .digest('hex');

    if (expected !== razorpay_signature) {
      await query(`UPDATE payments SET status='failed' WHERE id=$1`, [payment_id]);
      return res.status(400).json({ error: 'Payment verification failed' });
    }

    // Mark payment captured
    const { rows: [payment] } = await query(
      `UPDATE payments
       SET status='captured', razorpay_payment_id=$1, razorpay_signature=$2
       WHERE id=$3 RETURNING *`,
      [razorpay_payment_id, razorpay_signature, payment_id]
    );

    // Confirm order
    await query(
      `UPDATE orders SET status='confirmed' WHERE id=$1`,
      [payment.order_id]
    );
    await query(
      `INSERT INTO order_status_history (order_id, status, note) VALUES ($1,'confirmed','Payment captured')`,
      [payment.order_id]
    );

    // Emit socket event
    req.app.get('io')?.to(`order:${payment.order_id}`).emit('order_status', {
      order_id: payment.order_id, status: 'confirmed'
    });

    res.json({ success: true, payment });
  } catch (err) { next(err); }
});

// ── POST /api/payments/webhook ────────────────────────────────
// Razorpay webhook (for server-side confirmation fallback)
router.post('/webhook', express.raw({ type: 'application/json' }), async (req, res, next) => {
  try {
    const sig  = req.headers['x-razorpay-signature'];
    const body = req.body.toString();
    const expected = crypto
      .createHmac('sha256', process.env.RAZORPAY_WEBHOOK_SECRET || process.env.RAZORPAY_KEY_SECRET)
      .update(body).digest('hex');

    if (sig !== expected) return res.status(400).json({ error: 'Invalid webhook signature' });

    const event = JSON.parse(body);
    if (event.event === 'payment.captured') {
      const pid  = event.payload.payment.entity.id;
      const oid  = event.payload.payment.entity.order_id;
      await query(`UPDATE payments SET status='captured', razorpay_payment_id=$1 WHERE razorpay_order_id=$2`, [pid, oid]);
      const { rows } = await query(`SELECT order_id FROM payments WHERE razorpay_order_id=$1`, [oid]);
      if (rows[0]) {
        await query(`UPDATE orders SET status='confirmed' WHERE id=$1 AND status='pending'`, [rows[0].order_id]);
      }
    }

    res.json({ received: true });
  } catch (err) { next(err); }
});

// ── POST /api/payments/:id/refund ─────────────────────────────
router.post('/:id/refund', authenticate, async (req, res, next) => {
  try {
    const { rows: [payment] } = await query('SELECT * FROM payments WHERE id=$1', [req.params.id]);
    if (!payment) return res.status(404).json({ error: 'Payment not found' });
    if (payment.status !== 'captured') return res.status(400).json({ error: 'Payment not refundable' });

    const amount = req.body.amount || payment.amount;
    const refund = await razorpay.payments.refund(payment.razorpay_payment_id, {
      amount: Math.round(amount * 100),
      notes: { reason: req.body.reason || 'Customer request' },
    });

    await query(
      `UPDATE payments SET status='refunded', refund_id=$1, refund_amount=$2, refunded_at=NOW() WHERE id=$3`,
      [refund.id, amount, payment.id]
    );
    await query(`UPDATE orders SET status='refunded' WHERE id=$1`, [payment.order_id]);

    res.json({ refund_id: refund.id, amount });
  } catch (err) { next(err); }
});

module.exports = router;
