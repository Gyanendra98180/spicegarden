const nodemailer = require('nodemailer');
let twilio, admin;

// Lazy-load to avoid crash if env vars are missing in dev
function getTwilio() {
  if (!twilio && process.env.TWILIO_ACCOUNT_SID) {
    twilio = require('twilio')(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
  }
  return twilio;
}

function getFirebaseAdmin() {
  if (!admin && process.env.FIREBASE_PROJECT_ID) {
    admin = require('firebase-admin').initializeApp({
      credential: require('firebase-admin').credential.cert({
        projectId:    process.env.FIREBASE_PROJECT_ID,
        clientEmail:  process.env.FIREBASE_CLIENT_EMAIL,
        privateKey:   process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n'),
      }),
    });
  }
  return admin;
}

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'smtp.gmail.com',
  port: Number(process.env.SMTP_PORT) || 587,
  auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
});

// ── OTP ──────────────────────────────────────────────────────

async function sendOTP(target, code) {
  const isPhone = /^\+?[0-9]{10,15}$/.test(target.replace(/\s/g, ''));

  if (isPhone) {
    const client = getTwilio();
    if (!client) { console.log(`[DEV] OTP for ${target}: ${code}`); return; }
    await client.messages.create({
      body: `Your Spice Garden OTP is ${code}. Valid for 10 minutes.`,
      from: process.env.TWILIO_PHONE,
      to:   target,
    });
  } else {
    await transporter.sendMail({
      from:    process.env.EMAIL_FROM,
      to:      target,
      subject: 'Spice Garden — Your OTP',
      html: `
        <div style="font-family:sans-serif;max-width:480px;margin:auto">
          <h2 style="color:#D85A30">Spice Garden 🍽</h2>
          <p>Your one-time password is:</p>
          <div style="font-size:32px;font-weight:bold;letter-spacing:8px;color:#D85A30;margin:16px 0">${code}</div>
          <p style="color:#888;font-size:13px">Valid for 10 minutes. Do not share this with anyone.</p>
        </div>
      `,
    });
  }
}

// ── Welcome Email ────────────────────────────────────────────

async function sendWelcomeEmail(email, name) {
  await transporter.sendMail({
    from:    process.env.EMAIL_FROM,
    to:      email,
    subject: 'Welcome to Spice Garden! 🌶',
    html: `
      <div style="font-family:sans-serif;max-width:480px;margin:auto">
        <h2 style="color:#D85A30">Welcome, ${name}! 🍽</h2>
        <p>Thanks for joining Spice Garden. Explore our menu of authentic Indian cuisine.</p>
        <p>Use code <strong>WELCOME20</strong> for 20% off your first order!</p>
        <a href="${process.env.FRONTEND_URL}" style="background:#D85A30;color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;display:inline-block;margin-top:12px">Order Now</a>
      </div>
    `,
  });
}

// ── Order Confirmation Email ─────────────────────────────────

async function sendOrderConfirmation(email, order) {
  await transporter.sendMail({
    from:    process.env.EMAIL_FROM,
    to:      email,
    subject: `Order Confirmed — #${order.order_number} 🎉`,
    html: `
      <div style="font-family:sans-serif;max-width:480px;margin:auto">
        <h2 style="color:#D85A30">Order confirmed! 🎉</h2>
        <p>Order <strong>#${order.order_number}</strong> has been placed successfully.</p>
        <table style="width:100%;border-collapse:collapse;margin:16px 0">
          <tr><td style="color:#888">Subtotal</td><td style="text-align:right">₹${order.subtotal}</td></tr>
          <tr><td style="color:#888">Tax</td><td style="text-align:right">₹${order.tax_amount}</td></tr>
          <tr><td style="color:#888">Delivery</td><td style="text-align:right">₹${order.delivery_fee}</td></tr>
          <tr><td><strong>Total</strong></td><td style="text-align:right"><strong>₹${order.total_amount}</strong></td></tr>
        </table>
        <p style="color:#888">Estimated delivery: 35–45 minutes</p>
      </div>
    `,
  });
}

// ── Push Notification ────────────────────────────────────────

async function sendPushNotification(fcmToken, title, body, data = {}) {
  const app = getFirebaseAdmin();
  if (!app) { console.log(`[DEV] Push: ${title} — ${body}`); return; }

  await require('firebase-admin').messaging().send({
    token: fcmToken,
    notification: { title, body },
    data: Object.fromEntries(Object.entries(data).map(([k, v]) => [k, String(v)])),
    android: { priority: 'high' },
    apns: { payload: { aps: { sound: 'default' } } },
  });
}

module.exports = { sendOTP, sendWelcomeEmail, sendOrderConfirmation, sendPushNotification };
