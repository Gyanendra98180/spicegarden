-- ============================================================
-- SPICE GARDEN RESTAURANT APP — COMPLETE DATABASE SCHEMA
-- PostgreSQL 15+
-- ============================================================

-- Enable extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================
-- USERS & AUTH
-- ============================================================

CREATE TABLE users (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name          VARCHAR(100) NOT NULL,
  email         VARCHAR(255) UNIQUE,
  phone         VARCHAR(20)  UNIQUE,
  password_hash TEXT,
  role          VARCHAR(20)  NOT NULL DEFAULT 'customer' CHECK (role IN ('customer','admin','staff')),
  avatar_url    TEXT,
  is_verified   BOOLEAN      NOT NULL DEFAULT FALSE,
  is_active     BOOLEAN      NOT NULL DEFAULT TRUE,
  fcm_token     TEXT,
  created_at    TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE TABLE otp_codes (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  target      VARCHAR(255) NOT NULL,   -- email or phone
  code        VARCHAR(10)  NOT NULL,
  purpose     VARCHAR(30)  NOT NULL CHECK (purpose IN ('login','signup','reset')),
  expires_at  TIMESTAMPTZ  NOT NULL,
  used        BOOLEAN      NOT NULL DEFAULT FALSE,
  created_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE TABLE refresh_tokens (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash  TEXT NOT NULL UNIQUE,
  expires_at  TIMESTAMPTZ NOT NULL,
  revoked     BOOLEAN NOT NULL DEFAULT FALSE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- ADDRESSES
-- ============================================================

CREATE TABLE addresses (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  label       VARCHAR(50),                          -- 'Home', 'Office', etc.
  line1       VARCHAR(255) NOT NULL,
  line2       VARCHAR(255),
  city        VARCHAR(100) NOT NULL,
  state       VARCHAR(100) NOT NULL,
  pincode     VARCHAR(10)  NOT NULL,
  lat         DECIMAL(10,8),
  lng         DECIMAL(11,8),
  is_default  BOOLEAN NOT NULL DEFAULT FALSE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- MENU
-- ============================================================

CREATE TABLE categories (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name        VARCHAR(100) NOT NULL UNIQUE,
  slug        VARCHAR(100) NOT NULL UNIQUE,
  description TEXT,
  image_url   TEXT,
  sort_order  INTEGER NOT NULL DEFAULT 0,
  is_active   BOOLEAN NOT NULL DEFAULT TRUE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE menu_items (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  category_id     UUID NOT NULL REFERENCES categories(id),
  name            VARCHAR(150) NOT NULL,
  slug            VARCHAR(150) NOT NULL UNIQUE,
  description     TEXT,
  price           DECIMAL(10,2) NOT NULL CHECK (price >= 0),
  compare_price   DECIMAL(10,2),                   -- original price for discounts
  image_url       TEXT,
  emoji           VARCHAR(10),
  is_veg          BOOLEAN NOT NULL DEFAULT TRUE,
  is_vegan        BOOLEAN NOT NULL DEFAULT FALSE,
  is_gluten_free  BOOLEAN NOT NULL DEFAULT FALSE,
  spice_level     INTEGER CHECK (spice_level BETWEEN 0 AND 3),
  calories        INTEGER,
  prep_time_mins  INTEGER,
  is_available    BOOLEAN NOT NULL DEFAULT TRUE,
  is_featured     BOOLEAN NOT NULL DEFAULT FALSE,
  sort_order      INTEGER NOT NULL DEFAULT 0,
  tags            TEXT[],
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE item_customizations (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  item_id      UUID NOT NULL REFERENCES menu_items(id) ON DELETE CASCADE,
  name         VARCHAR(100) NOT NULL,              -- "Size", "Spice Level"
  type         VARCHAR(20) NOT NULL CHECK (type IN ('single','multi')),
  is_required  BOOLEAN NOT NULL DEFAULT FALSE,
  options      JSONB NOT NULL,                     -- [{label, price_delta}]
  sort_order   INTEGER NOT NULL DEFAULT 0
);

-- ============================================================
-- COUPONS
-- ============================================================

CREATE TABLE coupons (
  id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  code              VARCHAR(30) NOT NULL UNIQUE,
  description       TEXT,
  type              VARCHAR(20) NOT NULL CHECK (type IN ('percent','flat','free_delivery')),
  value             DECIMAL(10,2) NOT NULL,
  min_order_amount  DECIMAL(10,2) NOT NULL DEFAULT 0,
  max_discount      DECIMAL(10,2),
  usage_limit       INTEGER,
  usage_count       INTEGER NOT NULL DEFAULT 0,
  per_user_limit    INTEGER NOT NULL DEFAULT 1,
  valid_from        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  valid_until       TIMESTAMPTZ,
  is_active         BOOLEAN NOT NULL DEFAULT TRUE,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE coupon_usages (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  coupon_id   UUID NOT NULL REFERENCES coupons(id),
  user_id     UUID REFERENCES users(id),
  order_id    UUID,                               -- FK added after orders table
  used_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- ORDERS
-- ============================================================

CREATE TYPE order_status AS ENUM (
  'pending','confirmed','preparing','ready',
  'out_for_delivery','delivered','cancelled','refunded'
);

CREATE TYPE order_type AS ENUM ('delivery','pickup');

CREATE TABLE orders (
  id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_number      VARCHAR(20) NOT NULL UNIQUE,
  user_id           UUID REFERENCES users(id),
  guest_name        VARCHAR(100),
  guest_email       VARCHAR(255),
  guest_phone       VARCHAR(20),
  type              order_type NOT NULL DEFAULT 'delivery',
  status            order_status NOT NULL DEFAULT 'pending',
  address_id        UUID REFERENCES addresses(id),
  delivery_address  JSONB,                        -- snapshot of address
  coupon_id         UUID REFERENCES coupons(id),
  subtotal          DECIMAL(10,2) NOT NULL,
  tax_amount        DECIMAL(10,2) NOT NULL DEFAULT 0,
  delivery_fee      DECIMAL(10,2) NOT NULL DEFAULT 0,
  discount_amount   DECIMAL(10,2) NOT NULL DEFAULT 0,
  total_amount      DECIMAL(10,2) NOT NULL,
  special_instructions TEXT,
  estimated_delivery_at TIMESTAMPTZ,
  delivered_at      TIMESTAMPTZ,
  cancelled_at      TIMESTAMPTZ,
  cancel_reason     TEXT,
  rider_id          UUID REFERENCES users(id),
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE order_items (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id        UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  item_id         UUID NOT NULL REFERENCES menu_items(id),
  item_snapshot   JSONB NOT NULL,                 -- name, price, image at time of order
  quantity        INTEGER NOT NULL CHECK (quantity > 0),
  unit_price      DECIMAL(10,2) NOT NULL,
  customizations  JSONB,
  line_total      DECIMAL(10,2) NOT NULL
);

CREATE TABLE order_status_history (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id    UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  status      order_status NOT NULL,
  note        TEXT,
  changed_by  UUID REFERENCES users(id),
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Add FK to coupon_usages now that orders table exists
ALTER TABLE coupon_usages ADD CONSTRAINT fk_coupon_order
  FOREIGN KEY (order_id) REFERENCES orders(id);

-- ============================================================
-- PAYMENTS
-- ============================================================

CREATE TYPE payment_status AS ENUM (
  'pending','processing','captured','failed','refunded','partially_refunded'
);

CREATE TYPE payment_method AS ENUM (
  'upi','card','wallet','cod','netbanking'
);

CREATE TABLE payments (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id            UUID NOT NULL REFERENCES orders(id),
  razorpay_order_id   TEXT UNIQUE,
  razorpay_payment_id TEXT UNIQUE,
  razorpay_signature  TEXT,
  method              payment_method NOT NULL,
  amount              DECIMAL(10,2) NOT NULL,
  currency            VARCHAR(5) NOT NULL DEFAULT 'INR',
  status              payment_status NOT NULL DEFAULT 'pending',
  gateway_response    JSONB,
  refund_id           TEXT,
  refund_amount       DECIMAL(10,2),
  refunded_at         TIMESTAMPTZ,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- REVIEWS
-- ============================================================

CREATE TABLE reviews (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID NOT NULL REFERENCES users(id),
  order_id    UUID NOT NULL REFERENCES orders(id),
  item_id     UUID REFERENCES menu_items(id),    -- NULL = overall order review
  rating      INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment     TEXT,
  is_visible  BOOLEAN NOT NULL DEFAULT TRUE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- NOTIFICATIONS
-- ============================================================

CREATE TABLE notifications (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title       VARCHAR(200) NOT NULL,
  body        TEXT NOT NULL,
  type        VARCHAR(50),
  data        JSONB,
  is_read     BOOLEAN NOT NULL DEFAULT FALSE,
  sent_at     TIMESTAMPTZ,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- ANALYTICS / REPORTING
-- ============================================================

CREATE TABLE daily_reports (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  report_date     DATE NOT NULL UNIQUE,
  total_orders    INTEGER NOT NULL DEFAULT 0,
  total_revenue   DECIMAL(12,2) NOT NULL DEFAULT 0,
  total_discount  DECIMAL(12,2) NOT NULL DEFAULT 0,
  avg_order_value DECIMAL(10,2) NOT NULL DEFAULT 0,
  new_customers   INTEGER NOT NULL DEFAULT 0,
  cancelled_count INTEGER NOT NULL DEFAULT 0,
  top_items       JSONB,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- INDEXES
-- ============================================================

CREATE INDEX idx_users_email   ON users(email);
CREATE INDEX idx_users_phone   ON users(phone);
CREATE INDEX idx_menu_items_category ON menu_items(category_id);
CREATE INDEX idx_menu_items_available ON menu_items(is_available);
CREATE INDEX idx_orders_user   ON orders(user_id);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_orders_created ON orders(created_at DESC);
CREATE INDEX idx_order_items_order ON order_items(order_id);
CREATE INDEX idx_payments_order ON payments(order_id);
CREATE INDEX idx_reviews_item  ON reviews(item_id);
CREATE INDEX idx_notifications_user ON notifications(user_id, is_read);
CREATE INDEX idx_otp_target    ON otp_codes(target, expires_at);

-- ============================================================
-- UPDATED_AT TRIGGER
-- ============================================================

CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_users_updated         BEFORE UPDATE ON users         FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_menu_items_updated    BEFORE UPDATE ON menu_items    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_orders_updated        BEFORE UPDATE ON orders        FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_payments_updated      BEFORE UPDATE ON payments      FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ============================================================
-- VIEWS FOR REPORTING
-- ============================================================

CREATE VIEW v_order_summary AS
SELECT
  o.id,
  o.order_number,
  o.status,
  o.type,
  o.total_amount,
  o.created_at,
  COALESCE(u.name, o.guest_name) AS customer_name,
  COALESCE(u.phone, o.guest_phone) AS customer_phone,
  p.status AS payment_status,
  p.method AS payment_method,
  COUNT(oi.id) AS item_count
FROM orders o
LEFT JOIN users u ON o.user_id = u.id
LEFT JOIN payments p ON p.order_id = o.id
LEFT JOIN order_items oi ON oi.order_id = o.id
GROUP BY o.id, u.name, u.phone, p.status, p.method;

CREATE VIEW v_menu_with_ratings AS
SELECT
  m.*,
  c.name AS category_name,
  ROUND(AVG(r.rating)::NUMERIC, 1) AS avg_rating,
  COUNT(r.id) AS review_count
FROM menu_items m
JOIN categories c ON m.category_id = c.id
LEFT JOIN reviews r ON r.item_id = m.id AND r.is_visible = TRUE
GROUP BY m.id, c.name;
