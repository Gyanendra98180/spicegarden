-- ============================================================
-- SEED DATA — Spice Garden
-- ============================================================

-- Admin user (password: Admin@123)
INSERT INTO users (name, email, phone, password_hash, role, is_verified) VALUES
('Restaurant Owner', 'admin@spicegarden.in', '+911234567890',
 crypt('Admin@123', gen_salt('bf')), 'admin', TRUE),
('Demo Customer', 'customer@demo.com', '+919876543210',
 crypt('Demo@123', gen_salt('bf')), 'customer', TRUE);

-- Categories
INSERT INTO categories (name, slug, sort_order) VALUES
('Starters',    'starters',    1),
('Main Course', 'main-course', 2),
('Breads',      'breads',      3),
('Desserts',    'desserts',    4),
('Beverages',   'beverages',   5);

-- Menu items
WITH cats AS (SELECT id, slug FROM categories)
INSERT INTO menu_items (category_id, name, slug, description, price, emoji, is_veg, spice_level, prep_time_mins, is_available, is_featured) VALUES
((SELECT id FROM cats WHERE slug='starters'),    'Paneer Tikka',      'paneer-tikka',      'Marinated paneer grilled in tandoor with spiced yogurt',           280, '🫕', TRUE,  2, 15, TRUE,  TRUE),
((SELECT id FROM cats WHERE slug='starters'),    'Veg Spring Rolls',  'veg-spring-rolls',  'Crispy rolls stuffed with seasoned vegetables',                    160, '🥢', TRUE,  1, 10, TRUE,  FALSE),
((SELECT id FROM cats WHERE slug='starters'),    'Chicken Tikka',     'chicken-tikka',     'Tender chicken marinated in spiced yogurt, tandoor grilled',       320, '🍗', FALSE, 2, 15, TRUE,  TRUE),
((SELECT id FROM cats WHERE slug='starters'),    'Samosa (2 pcs)',    'samosa',            'Golden fried pastry filled with spiced potato',                    80,  '🔺', TRUE,  1, 5,  TRUE,  FALSE),
((SELECT id FROM cats WHERE slug='starters'),    'Soup of the Day',   'soup-of-day',       'Chef''s choice — ask server for today''s option',                  120, '🍲', TRUE,  0, 10, FALSE, FALSE),
((SELECT id FROM cats WHERE slug='main-course'), 'Butter Chicken',    'butter-chicken',    'Slow-cooked chicken in rich tomato-butter gravy',                  380, '🍛', FALSE, 2, 20, TRUE,  TRUE),
((SELECT id FROM cats WHERE slug='main-course'), 'Dal Makhani',       'dal-makhani',       'Black lentils simmered overnight with cream & spices',             260, '🫘', TRUE,  1, 25, TRUE,  TRUE),
((SELECT id FROM cats WHERE slug='main-course'), 'Palak Paneer',      'palak-paneer',      'Cottage cheese in creamy spinach gravy',                           290, '🥬', TRUE,  1, 20, TRUE,  FALSE),
((SELECT id FROM cats WHERE slug='main-course'), 'Veg Biryani',       'veg-biryani',       'Fragrant basmati rice layered with vegetables & saffron',          300, '🍚', TRUE,  2, 25, TRUE,  FALSE),
((SELECT id FROM cats WHERE slug='main-course'), 'Chicken Biryani',   'chicken-biryani',   'Aromatic biryani with succulent chicken pieces',                   380, '🍱', FALSE, 2, 25, TRUE,  TRUE),
((SELECT id FROM cats WHERE slug='main-course'), 'Kadhai Mushroom',   'kadhai-mushroom',   'Button mushrooms tossed in bold kadhai masala',                    270, '🍄', TRUE,  3, 20, TRUE,  FALSE),
((SELECT id FROM cats WHERE slug='breads'),      'Naan',              'naan',              'Soft leavened bread baked in tandoor',                             50,  '🫓', TRUE,  0, 8,  TRUE,  FALSE),
((SELECT id FROM cats WHERE slug='breads'),      'Garlic Naan',       'garlic-naan',       'Naan topped with minced garlic and butter',                        70,  '🧄', TRUE,  0, 8,  TRUE,  TRUE),
((SELECT id FROM cats WHERE slug='breads'),      'Laccha Paratha',    'laccha-paratha',    'Layered whole-wheat bread, flaky and crispy',                      60,  '🌾', TRUE,  0, 8,  TRUE,  FALSE),
((SELECT id FROM cats WHERE slug='breads'),      'Tandoori Roti',     'tandoori-roti',     'Whole-wheat bread baked in clay oven',                             40,  '🍞', TRUE,  0, 6,  TRUE,  FALSE),
((SELECT id FROM cats WHERE slug='desserts'),    'Gulab Jamun',       'gulab-jamun',       'Soft milk dumplings soaked in rose-cardamom syrup',                100, '🍮', TRUE,  0, 5,  TRUE,  TRUE),
((SELECT id FROM cats WHERE slug='desserts'),    'Kulfi',             'kulfi',             'Traditional frozen dessert with pistachios',                       120, '🍦', TRUE,  0, 0,  TRUE,  FALSE),
((SELECT id FROM cats WHERE slug='desserts'),    'Ras Malai',         'ras-malai',         'Soft paneer discs in saffron-infused chilled milk',                130, '🥛', TRUE,  0, 5,  TRUE,  FALSE),
((SELECT id FROM cats WHERE slug='beverages'),   'Mango Lassi',       'mango-lassi',       'Chilled yogurt blended with Alphonso mangoes',                     100, '🥭', TRUE,  0, 5,  TRUE,  TRUE),
((SELECT id FROM cats WHERE slug='beverages'),   'Masala Chai',       'masala-chai',       'Spiced Indian tea with milk, ginger & cardamom',                   60,  '🍵', TRUE,  0, 5,  TRUE,  FALSE),
((SELECT id FROM cats WHERE slug='beverages'),   'Fresh Lime Soda',   'fresh-lime-soda',   'Chilled lime squeezed over soda with a pinch of salt',             80,  '🍋', TRUE,  0, 3,  TRUE,  FALSE),
((SELECT id FROM cats WHERE slug='beverages'),   'Watermelon Juice',  'watermelon-juice',  'Fresh pressed, chilled watermelon juice',                          90,  '🍉', TRUE,  0, 3,  TRUE,  FALSE);

-- Coupons
INSERT INTO coupons (code, description, type, value, min_order_amount, max_discount, usage_limit, valid_until) VALUES
('WELCOME20',  'Welcome offer — 20% off first order', 'percent',       20,  100,   200,  NULL, NOW() + INTERVAL '1 year'),
('SPICE10',    '10% off on all orders',               'percent',       10,  200,   100,  5000, NOW() + INTERVAL '6 months'),
('FLAT50',     'Flat ₹50 off on orders above ₹400',  'flat',          50,  400,   50,   1000, NOW() + INTERVAL '3 months'),
('FREEDEL',    'Free delivery on orders above ₹300',  'free_delivery', 40,  300,   40,   NULL, NOW() + INTERVAL '1 year');
