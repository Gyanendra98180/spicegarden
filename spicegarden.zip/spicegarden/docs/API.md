# Spice Garden — API Reference

Base URL: `https://api.spicegarden.in/api`  
Auth: `Authorization: Bearer <access_token>`

---

## Authentication

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/auth/signup` | — | Register with name, email/phone, password |
| POST | `/auth/login` | — | Login with email/phone + password |
| POST | `/auth/send-otp` | — | Send OTP to phone/email |
| POST | `/auth/verify-otp` | — | Verify OTP and receive tokens |
| POST | `/auth/refresh` | — | Refresh access token |
| POST | `/auth/logout` | ✅ | Revoke refresh token |
| GET | `/auth/me` | ✅ | Get current user |
| PATCH | `/auth/me` | ✅ | Update profile |

### Signup request
```json
{
  "name": "Rahul Sharma",
  "email": "rahul@example.com",
  "phone": "+919876543210",
  "password": "SecurePass123"
}
```

### Login response
```json
{
  "user": { "id": "uuid", "name": "Rahul", "role": "customer" },
  "access_token": "eyJ...",
  "refresh_token": "eyJ..."
}
```

---

## Menu

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/menu/categories` | — | List all categories |
| GET | `/menu/items` | — | List items (filter: `category`, `search`, `veg`, `featured`) |
| GET | `/menu/items/:slug` | — | Get item detail + reviews |
| POST | `/menu/items` | Admin | Create menu item |
| PATCH | `/menu/items/:id` | Admin | Update menu item |
| DELETE | `/menu/items/:id` | Admin | Deactivate item |

### Query parameters for GET /menu/items
| Param | Type | Example |
|-------|------|---------|
| `category` | string | `main-course` |
| `search` | string | `paneer` |
| `veg` | boolean | `true` |
| `featured` | boolean | `true` |
| `page` | number | `1` |
| `limit` | number | `20` |

---

## Orders

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/orders` | Optional | Place an order (supports guest checkout) |
| GET | `/orders` | ✅ | List user's orders |
| GET | `/orders/:id` | Optional | Get order detail + items + status history |
| PATCH | `/orders/:id/status` | Admin/Staff | Update order status |

### Place order request
```json
{
  "items": [
    { "item_id": "uuid", "quantity": 2 },
    { "item_id": "uuid", "quantity": 1 }
  ],
  "type": "delivery",
  "delivery_address": {
    "line1": "Flat 4B, Tower 3",
    "line2": "Sector 18, Noida",
    "city": "Noida",
    "state": "UP",
    "pincode": "201301"
  },
  "coupon_code": "WELCOME20",
  "special_instructions": "Extra spicy please"
}
```

### Order status flow
```
pending → confirmed → preparing → out_for_delivery → delivered
                                → ready (pickup only)
any → cancelled
delivered → refunded
```

---

## Payments (Razorpay)

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/payments/create-order` | Optional | Create Razorpay order |
| POST | `/payments/verify` | Optional | Verify payment signature |
| POST | `/payments/webhook` | — | Razorpay webhook handler |
| POST | `/payments/:id/refund` | Admin | Initiate refund |

### Payment flow
```
1. POST /orders          → get order.id
2. POST /payments/create-order { order_id } → get razorpay_order_id + key_id
3. Open Razorpay checkout SDK on frontend
4. On success → POST /payments/verify { razorpay_order_id, razorpay_payment_id, razorpay_signature }
5. Order status auto-updates to "confirmed"
```

---

## Coupons

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/coupons/validate` | — | Validate coupon code |
| GET | `/coupons` | Admin | List all coupons |
| POST | `/coupons` | Admin | Create coupon |

### Validate request
```json
{ "code": "WELCOME20", "amount": 450 }
```
### Validate response
```json
{ "code": "WELCOME20", "type": "percent", "value": 20, "discount": 90 }
```

---

## Reviews

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/reviews` | ✅ | Submit review for order/item |
| GET | `/reviews?item_id=uuid` | — | Get reviews for an item |

---

## Addresses

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/addresses` | ✅ | List saved addresses |
| POST | `/addresses` | ✅ | Add new address |
| PATCH | `/addresses/:id` | ✅ | Update address |
| DELETE | `/addresses/:id` | ✅ | Delete address |

---

## Admin

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/admin/dashboard` | Admin | Today's stats |
| GET | `/admin/reports?from=&to=` | Admin | Daily revenue report |
| GET | `/admin/orders?status=` | Admin | All orders with filters |
| GET | `/admin/users` | Admin | All customers with spend |

---

## Error format
```json
{
  "error": "Human-readable message",
  "details": [{ "field": "email", "message": "Invalid email" }]
}
```

## HTTP status codes
| Code | Meaning |
|------|---------|
| 200 | OK |
| 201 | Created |
| 400 | Bad request / validation error |
| 401 | Unauthenticated |
| 403 | Forbidden |
| 404 | Not found |
| 409 | Conflict (duplicate) |
| 429 | Rate limited |
| 500 | Server error |
