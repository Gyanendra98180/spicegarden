# 🚀 Netlify Deployment Guide — Spice Garden

## Method 1: Deploy via GitHub (Recommended — Auto-deploys on every push)

### Step 1 — Push code to GitHub first
```bash
cd spicegarden
git init
git config user.name "Gyanendra98180"
git config user.email "gyanendrachaudhary182@gmail.com"
git add .
git commit -m "🎉 Initial commit"
git remote add origin https://github.com/Gyanendra98180/spicegarden.git
git branch -M main
git push -u origin main
```

### Step 2 — Connect to Netlify
1. Go to → https://app.netlify.com
2. Click **"Add new site"** → **"Import an existing project"**
3. Click **"GitHub"**
4. Authorize Netlify to access your GitHub
5. Search and select **"spicegarden"**

### Step 3 — Configure build settings
Netlify will auto-detect these from `netlify.toml`, but verify:

| Setting | Value |
|---------|-------|
| Base directory | `frontend` |
| Build command | `npm run build` |
| Publish directory | `frontend/.next` |
| Node version | `20` |

### Step 4 — Add Environment Variables
In Netlify → Site configuration → Environment variables → Add:

| Key | Value |
|-----|-------|
| `NEXT_PUBLIC_API_URL` | `https://your-backend.up.railway.app/api` |
| `NEXT_PUBLIC_SOCKET_URL` | `https://your-backend.up.railway.app` |
| `NEXT_PUBLIC_RAZORPAY_KEY_ID` | `rzp_test_XXXXXXXXXX` |
| `NEXT_PUBLIC_APP_NAME` | `Spice Garden` |

### Step 5 — Deploy!
Click **"Deploy site"** — Netlify builds and deploys automatically.

Your site will be live at:
`https://spicegarden-gyanendra.netlify.app`

---

## Method 2: Deploy via Netlify CLI (from terminal)

```bash
# Install Netlify CLI
npm install -g netlify-cli

# Login
netlify login

# Go to frontend folder
cd spicegarden/frontend

# Install dependencies
npm install

# Build
npm run build

# Deploy (preview first)
netlify deploy --dir=.next

# Deploy to production
netlify deploy --dir=.next --prod
```

---

## Method 3: Drag & Drop (Quickest — no GitHub needed)

1. Go to → https://app.netlify.com/drop
2. Build locally:
   ```bash
   cd spicegarden/frontend
   npm install
   npm run build
   ```
3. Drag the **`frontend/.next`** folder into the Netlify drop zone
4. Done! ✅

---

## GitHub Secrets (for auto CI/CD)

After deploying manually once, add these to GitHub:
**GitHub repo → Settings → Secrets and variables → Actions → New secret**

| Secret | Where to get it |
|--------|----------------|
| `NETLIFY_AUTH_TOKEN` | netlify.com → User settings → Applications → Personal access tokens |
| `NETLIFY_SITE_ID` | Netlify → Site configuration → Site ID |
| `NEXT_PUBLIC_API_URL` | Your Railway backend URL |
| `NEXT_PUBLIC_RAZORPAY_KEY_ID` | Razorpay dashboard |
| `RAILWAY_TOKEN` | railway.app → Account Settings → Tokens |

---

## Custom Domain (Optional)

1. Netlify → Domain management → Add custom domain
2. Enter: `spicegarden.in` (or any domain you own)
3. Update DNS at your registrar:
   ```
   Type: CNAME
   Name: www
   Value: spicegarden-gyanendra.netlify.app
   ```
4. Netlify auto-provisions free SSL certificate ✅

---

## After Deployment Checklist

- [ ] Site loads at your `.netlify.app` URL
- [ ] Menu items display (connected to backend)
- [ ] Can add items to cart
- [ ] Login/OTP works
- [ ] Razorpay payment opens
- [ ] Order tracking shows real-time updates
- [ ] Admin panel accessible

---

## Troubleshooting

**Build fails?**
- Check Node version is 20 in Netlify settings
- Ensure all env variables are set
- Check build logs for TypeScript errors

**API not connecting?**
- Verify `NEXT_PUBLIC_API_URL` points to your Railway backend
- Make sure CORS is enabled on backend for your Netlify domain

**Pages returning 404?**
- The `netlify.toml` redirects handle this automatically
- If still happening, check the `[[redirects]]` section is present
