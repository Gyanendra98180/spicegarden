# Spice Garden — Complete Setup & Deployment Guide

## Project Structure

```
spicegarden/
├── frontend/              # Next.js 14 app (React, TypeScript, Tailwind)
│   ├── src/
│   │   ├── app/           # App Router pages
│   │   │   ├── page.tsx            # Home / menu
│   │   │   ├── cart/               # Cart
│   │   │   ├── checkout/           # Checkout
│   │   │   ├── payment/            # Razorpay payment
│   │   │   ├── orders/             # Order list + tracking
│   │   │   ├── profile/            # User profile
│   │   │   ├── admin/              # Admin panel
│   │   │   └── auth/login/         # Auth screens
│   │   ├── components/    # Reusable UI components
│   │   ├── store/         # Zustand (cart + auth state)
│   │   └── lib/api.ts     # Axios API client
│   └── public/            # Static assets, manifest
│
├── backend/               # Node.js + Express API
│   └── src/
│       ├── routes/        # auth, menu, orders, payments, admin...
│       ├── middleware/     # auth, errorHandler, socketAuth
│       ├── services/       # notifications (email/SMS/push)
│       └── utils/         # db pool
│
├── database/
│   ├── migrations/001_schema.sql   # Full PostgreSQL schema
│   └── seeds/001_seed.sql          # Categories, menu items, coupons
│
├── docs/
│   └── API.md             # Complete API reference
│
└── docker-compose.yml     # Full-stack local dev
```

---

## Prerequisites

- Node.js 20+
- PostgreSQL 15+
- npm or yarn

---

## Local Development (Manual)

### 1. Clone and install

```bash
# Backend
cd backend
cp .env.example .env        # Fill in your values
npm install
npm run dev                 # Starts on http://localhost:4000

# Frontend (new terminal)
cd frontend
cp .env.local.example .env.local
npm install
npm run dev                 # Starts on http://localhost:3000
```

### 2. Setup database

```bash
psql -U postgres -c "CREATE DATABASE spicegarden;"
psql -U postgres -d spicegarden -f database/migrations/001_schema.sql
psql -U postgres -d spicegarden -f database/seeds/001_seed.sql
```

---

## Local Development (Docker — easiest)

```bash
# Copy and fill env
cp backend/.env.example backend/.env

# Start everything
docker-compose up --build

# App:     http://localhost:3000
# API:     http://localhost:4000
# DB:      localhost:5432
```

---

## Environment Variables

### Backend (.env)

| Variable | Description |
|----------|-------------|
| `DATABASE_URL` | PostgreSQL connection string |
| `JWT_SECRET` | Long random string for access tokens |
| `JWT_REFRESH_SECRET` | Long random string for refresh tokens |
| `RAZORPAY_KEY_ID` | From Razorpay dashboard |
| `RAZORPAY_KEY_SECRET` | From Razorpay dashboard |
| `TWILIO_ACCOUNT_SID` | For SMS OTP |
| `TWILIO_AUTH_TOKEN` | Twilio auth token |
| `TWILIO_PHONE` | Your Twilio number |
| `SMTP_USER` | Gmail address for emails |
| `SMTP_PASS` | Gmail app password |
| `FIREBASE_PROJECT_ID` | For push notifications |
| `CLOUDINARY_CLOUD_NAME` | For image uploads |

### Frontend (.env.local)

| Variable | Description |
|----------|-------------|
| `NEXT_PUBLIC_API_URL` | Backend URL + /api |
| `NEXT_PUBLIC_SOCKET_URL` | Backend URL (for socket.io) |
| `NEXT_PUBLIC_RAZORPAY_KEY_ID` | Razorpay test/live key |

---

## Razorpay Setup

1. Create account at [razorpay.com](https://razorpay.com)
2. Go to Settings → API Keys → Generate test key
3. Copy `Key ID` and `Key Secret` to backend `.env`
4. Copy `Key ID` to frontend `.env.local`
5. For webhooks: Settings → Webhooks → Add URL: `https://your-api.com/api/payments/webhook`
   - Select events: `payment.captured`, `payment.failed`

---

## Production Deployment

### Backend → Railway / Render / DigitalOcean

```bash
# Railway
npm install -g @railway/cli
railway login
railway init
railway up

# Set env vars in Railway dashboard
```

### Frontend → Vercel (recommended)

```bash
npm install -g vercel
cd frontend
vercel --prod

# Set env vars in Vercel dashboard:
# NEXT_PUBLIC_API_URL=https://your-railway-api.up.railway.app/api
# NEXT_PUBLIC_SOCKET_URL=https://your-railway-api.up.railway.app
# NEXT_PUBLIC_RAZORPAY_KEY_ID=rzp_live_XXXX
```

### Database → Supabase / Neon (free tiers)

```bash
# Supabase
# 1. Create project at supabase.com
# 2. Get connection string from Settings → Database
# 3. Run migrations:
psql "postgresql://postgres:[PASSWORD]@[HOST]:5432/postgres" \
  -f database/migrations/001_schema.sql
psql "postgresql://..." -f database/seeds/001_seed.sql
```

---

## Admin Access

Default admin credentials (after seed):
- Email: `admin@spicegarden.in`
- Password: `Admin@123`

**Change immediately in production!**

Access admin panel: Profile → Admin Panel (visible only to admin role users)

---

## Key Features Checklist

- [x] Email + Phone signup/login
- [x] OTP verification (Twilio SMS + Nodemailer)
- [x] Guest checkout
- [x] JWT access + refresh token rotation
- [x] Full menu with categories, search, filters
- [x] Veg/non-veg indicators, ratings, availability
- [x] Cart with persist (localStorage via Zustand)
- [x] Coupon codes (%, flat, free delivery)
- [x] Delivery / pickup toggle
- [x] Saved addresses
- [x] Razorpay payment (UPI, card, wallet, COD)
- [x] Payment signature verification
- [x] Real-time order tracking via Socket.io
- [x] Push notifications via FCM
- [x] SMS/email order confirmation
- [x] Admin dashboard with live stats
- [x] Admin order status management
- [x] Menu item toggle (available/unavailable)
- [x] Ratings & reviews
- [x] Daily sales reports API
- [x] Docker Compose for local dev
- [x] Production-ready Dockerfiles
- [x] PWA manifest (installable on mobile)
- [x] Rate limiting + helmet security headers

---

## Tech Stack Summary

| Layer | Technology |
|-------|-----------|
| Frontend | Next.js 14, React 18, TypeScript, Tailwind CSS |
| State | Zustand (cart + auth), TanStack Query (server state) |
| Backend | Node.js, Express, Socket.io |
| Database | PostgreSQL 15 |
| Auth | JWT (access + refresh), bcrypt, OTP |
| Payments | Razorpay (UPI, cards, wallets, COD) |
| Email | Nodemailer (Gmail / SMTP) |
| SMS | Twilio |
| Push | Firebase Cloud Messaging |
| Images | Cloudinary |
| Containers | Docker, Docker Compose |
| Deploy | Vercel (frontend) + Railway (backend) + Supabase (DB) |
