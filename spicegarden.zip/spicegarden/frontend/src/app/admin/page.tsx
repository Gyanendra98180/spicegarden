'use client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { adminAPI, orderAPI, menuAPI } from '@/lib/api';
import { BottomNav } from '@/components/layout/BottomNav';
import { TrendingUp, ShoppingBag, Users, Star, Plus, ArrowLeft } from 'lucide-react';
import { useAuthStore } from '@/store/authStore';
import { useRouter } from 'next/navigation';
import toast from 'react-hot-toast';

const STATUS_OPTS = ['confirmed','preparing','ready','out_for_delivery','delivered','cancelled'];

export default function AdminPage() {
  const { user }  = useAuthStore();
  const router    = useRouter();
  const qc        = useQueryClient();

  if (user?.role !== 'admin') {
    return (
      <div className="max-w-lg mx-auto min-h-screen flex items-center justify-center">
        <p className="text-gray-400">Access denied</p>
      </div>
    );
  }

  const { data: dash }   = useQuery({ queryKey: ['admin-dash'],   queryFn: () => adminAPI.dashboard().then((r) => r.data) });
  const { data: orders = [] } = useQuery({ queryKey: ['admin-orders'], queryFn: () => adminAPI.orders().then((r) => r.data) });
  const { data: menuData }= useQuery({ queryKey: ['menu-items'], queryFn: () => menuAPI.getItems({ limit: 50 }).then((r) => r.data) });

  const updateStatus = useMutation({
    mutationFn: ({ id, status }: { id: string; status: string }) => orderAPI.updateStatus(id, { status }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['admin-orders'] }); toast.success('Status updated'); },
  });

  const toggleAvail = useMutation({
    mutationFn: ({ id, val }: { id: string; val: boolean }) => menuAPI.updateItem(id, { is_available: val }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['menu-items'] }); toast.success('Updated'); },
  });

  const STATS = [
    { label: "Today's revenue", val: `₹${(dash?.today_revenue || 0).toLocaleString('en-IN')}`, Icon: TrendingUp, color: 'text-[#D85A30]' },
    { label: "Today's orders",  val: dash?.today_orders || 0,   Icon: ShoppingBag, color: 'text-blue-500' },
    { label: 'New customers',   val: dash?.new_customers || 0,  Icon: Users,       color: 'text-green-500' },
    { label: 'Avg. rating',     val: '4.7',                     Icon: Star,        color: 'text-amber-500' },
  ];

  return (
    <div className="max-w-lg mx-auto bg-gray-50 min-h-screen pb-20">
      <div className="sticky top-0 bg-white border-b border-gray-100 px-4 py-3 flex items-center gap-3 z-10">
        <button onClick={() => router.back()}><ArrowLeft size={20} className="text-gray-600" /></button>
        <h1 className="text-base font-semibold">Admin Panel</h1>
        <span className="ml-auto chip chip-brand text-xs">Owner</span>
      </div>

      <div className="px-4 pt-4 space-y-5">
        {/* Stats */}
        <div className="grid grid-cols-2 gap-3">
          {STATS.map(({ label, val, Icon, color }) => (
            <div key={label} className="card p-4">
              <Icon size={18} className={`${color} mb-2`} />
              <p className="text-xl font-bold text-gray-800">{val}</p>
              <p className="text-xs text-gray-400 mt-0.5">{label}</p>
            </div>
          ))}
        </div>

        {/* Top items */}
        {dash?.top_items?.length > 0 && (
          <div className="card p-4">
            <h3 className="text-sm font-semibold text-gray-700 mb-3">Top items today</h3>
            {dash.top_items.map((item: any, i: number) => (
              <div key={i} className="flex items-center gap-2 py-1.5 border-b border-gray-50 last:border-0">
                <span className="text-lg">{item.emoji}</span>
                <span className="text-sm flex-1 text-gray-700">{item.name}</span>
                <span className="text-xs text-gray-400">{item.qty} sold</span>
                <span className="text-xs font-medium text-[#D85A30]">₹{item.revenue}</span>
              </div>
            ))}
          </div>
        )}

        {/* Active orders */}
        <div>
          <h3 className="text-sm font-semibold text-gray-700 mb-3">Live orders</h3>
          {orders.filter((o: any) => !['delivered','cancelled','refunded'].includes(o.status)).map((order: any) => (
            <div key={order.id} className="card p-4 mb-3">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <p className="text-sm font-semibold">#{order.order_number} · {order.customer_name}</p>
                  <p className="text-xs text-gray-400">{order.customer_phone} · ₹{order.total_amount}</p>
                </div>
                <span className="chip chip-amber capitalize text-xs">{order.status.replace(/_/g,' ')}</span>
              </div>
              <div className="flex gap-2 flex-wrap mt-2">
                {STATUS_OPTS.map((s) => (
                  <button
                    key={s}
                    onClick={() => updateStatus.mutate({ id: order.id, status: s })}
                    className={`text-xs px-3 py-1.5 rounded-lg border transition-all ${
                      order.status === s
                        ? 'bg-[#D85A30] text-white border-[#D85A30]'
                        : 'bg-white text-gray-600 border-gray-200 hover:border-[#D85A30]'
                    }`}
                  >
                    {s.replace(/_/g, ' ')}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Menu management */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold text-gray-700">Menu items</h3>
            <button
              onClick={() => toast.success('Add item form — connect to your CMS')}
              className="flex items-center gap-1 text-xs text-[#D85A30] font-medium"
            >
              <Plus size={14} /> Add item
            </button>
          </div>
          {(menuData?.items || []).slice(0, 8).map((item: any) => (
            <div key={item.id} className="card p-3 mb-2 flex items-center gap-3">
              <span className="text-2xl">{item.emoji}</span>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-800 truncate">{item.name}</p>
                <p className="text-xs text-gray-400">₹{item.price} · {item.category_name}</p>
              </div>
              <button
                onClick={() => toggleAvail.mutate({ id: item.id, val: !item.is_available })}
                className={`relative w-10 h-5 rounded-full transition-colors flex-shrink-0 ${
                  item.is_available ? 'bg-[#D85A30]' : 'bg-gray-200'
                }`}
              >
                <span className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-all ${
                  item.is_available ? 'left-5' : 'left-0.5'
                }`} />
              </button>
            </div>
          ))}
        </div>
      </div>

      <BottomNav />
    </div>
  );
}
