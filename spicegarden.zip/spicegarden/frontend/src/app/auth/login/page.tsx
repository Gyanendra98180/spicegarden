'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { authAPI } from '@/lib/api';
import { useAuthStore } from '@/store/authStore';
import { Eye, EyeOff, ArrowLeft } from 'lucide-react';
import toast from 'react-hot-toast';
import Link from 'next/link';

type Tab = 'login' | 'signup' | 'otp';

export default function LoginPage() {
  const router    = useRouter();
  const authStore = useAuthStore();
  const [tab, setTab]           = useState<Tab>('login');
  const [loading, setLoading]   = useState(false);
  const [showPw, setShowPw]     = useState(false);
  const [otpSent, setOtpSent]   = useState(false);
  const [otp, setOtp]           = useState('');
  const [form, setForm]         = useState({ name: '', email: '', phone: '', password: '', target: '' });

  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const { data } = await authAPI.login({ identifier: form.email || form.phone, password: form.password });
      authStore.setTokens(data.access_token, data.refresh_token);
      authStore.setUser(data.user);
      toast.success(`Welcome back, ${data.user.name}!`);
      router.push('/');
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Login failed');
    } finally { setLoading(false); }
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const { data } = await authAPI.signup(form);
      authStore.setTokens(data.access_token, data.refresh_token);
      authStore.setUser(data.user);
      toast.success(`Welcome to Spice Garden, ${data.user.name}!`);
      router.push('/');
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Signup failed');
    } finally { setLoading(false); }
  };

  const sendOTP = async () => {
    if (!form.target) return toast.error('Enter email or phone');
    setLoading(true);
    try {
      await authAPI.sendOTP({ target: form.target, purpose: 'login' });
      setOtpSent(true);
      toast.success('OTP sent!');
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Failed to send OTP');
    } finally { setLoading(false); }
  };

  const verifyOTP = async () => {
    if (otp.length < 6) return toast.error('Enter 6-digit OTP');
    setLoading(true);
    try {
      const { data } = await authAPI.verifyOTP({ target: form.target, code: otp, name: form.name });
      authStore.setTokens(data.access_token, data.refresh_token);
      authStore.setUser(data.user);
      toast.success('Verified! Welcome 🎉');
      router.push('/');
    } catch (err: any) {
      toast.error(err.response?.data?.error || 'Invalid OTP');
    } finally { setLoading(false); }
  };

  return (
    <div className="max-w-lg mx-auto min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <div className="px-4 pt-12 pb-8 bg-[#D85A30] text-white text-center">
        <div className="text-5xl mb-3">🍽</div>
        <h1 className="text-2xl font-bold">Spice Garden</h1>
        <p className="text-orange-200 text-sm mt-1">Authentic flavors, delivered to you</p>
      </div>

      <div className="flex-1 bg-white rounded-t-3xl -mt-4 px-6 pt-6 pb-10">
        {/* Tabs */}
        {tab !== 'otp' && (
          <div className="flex border-b border-gray-100 mb-6">
            {(['login', 'signup'] as Tab[]).map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={`flex-1 pb-3 text-sm font-medium capitalize border-b-2 transition-colors ${
                  tab === t ? 'text-[#D85A30] border-[#D85A30]' : 'text-gray-400 border-transparent'
                }`}
              >
                {t === 'login' ? 'Login' : 'Sign up'}
              </button>
            ))}
          </div>
        )}

        {/* Login Form */}
        {tab === 'login' && (
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="text-xs font-medium text-gray-500 block mb-1.5">Email or Phone</label>
              <input className="input" placeholder="you@email.com" value={form.email} onChange={set('email')} />
            </div>
            <div>
              <label className="text-xs font-medium text-gray-500 block mb-1.5">Password</label>
              <div className="relative">
                <input
                  className="input pr-10"
                  type={showPw ? 'text' : 'password'}
                  placeholder="••••••••"
                  value={form.password}
                  onChange={set('password')}
                />
                <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">
                  {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>
            <button type="submit" disabled={loading} className="btn-primary mt-2">
              {loading ? 'Logging in...' : 'Login'}
            </button>
            <div className="flex items-center gap-3 text-gray-300 my-2">
              <div className="flex-1 h-px bg-gray-100" />
              <span className="text-xs text-gray-400">or</span>
              <div className="flex-1 h-px bg-gray-100" />
            </div>
            <button type="button" onClick={() => setTab('otp')} className="btn-outline w-full">
              Login with OTP
            </button>
            <button type="button" onClick={() => router.push('/')} className="w-full text-sm text-gray-400 underline pt-1">
              Continue as guest
            </button>
          </form>
        )}

        {/* Signup Form */}
        {tab === 'signup' && (
          <form onSubmit={handleSignup} className="space-y-4">
            <div>
              <label className="text-xs font-medium text-gray-500 block mb-1.5">Full name</label>
              <input className="input" placeholder="Rahul Sharma" value={form.name} onChange={set('name')} required />
            </div>
            <div>
              <label className="text-xs font-medium text-gray-500 block mb-1.5">Email</label>
              <input className="input" type="email" placeholder="you@email.com" value={form.email} onChange={set('email')} />
            </div>
            <div>
              <label className="text-xs font-medium text-gray-500 block mb-1.5">Phone</label>
              <input className="input" type="tel" placeholder="+91 9876543210" value={form.phone} onChange={set('phone')} />
            </div>
            <div>
              <label className="text-xs font-medium text-gray-500 block mb-1.5">Password</label>
              <div className="relative">
                <input
                  className="input pr-10"
                  type={showPw ? 'text' : 'password'}
                  placeholder="Min 6 characters"
                  value={form.password}
                  onChange={set('password')}
                  required
                />
                <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">
                  {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>
            <button type="submit" disabled={loading} className="btn-primary mt-2">
              {loading ? 'Creating account...' : 'Create account'}
            </button>
          </form>
        )}

        {/* OTP Flow */}
        {tab === 'otp' && (
          <div>
            <button onClick={() => setTab('login')} className="flex items-center gap-1 text-sm text-gray-400 mb-5">
              <ArrowLeft size={16} /> Back
            </button>
            <h2 className="text-lg font-semibold mb-1">Login with OTP</h2>
            <p className="text-sm text-gray-400 mb-5">Enter your phone or email to receive a one-time password</p>
            {!otpSent ? (
              <div className="space-y-4">
                <div>
                  <label className="text-xs font-medium text-gray-500 block mb-1.5">Phone or Email</label>
                  <input className="input" placeholder="+91 9876543210 or email" value={form.target} onChange={set('target')} />
                </div>
                <button onClick={sendOTP} disabled={loading} className="btn-primary">
                  {loading ? 'Sending...' : 'Send OTP'}
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <p className="text-sm text-gray-600">OTP sent to <strong>{form.target}</strong></p>
                <div>
                  <label className="text-xs font-medium text-gray-500 block mb-1.5">6-digit OTP</label>
                  <input
                    className="input text-center text-2xl tracking-[12px] font-bold"
                    maxLength={6}
                    placeholder="––––––"
                    value={otp}
                    onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))}
                  />
                </div>
                <button onClick={verifyOTP} disabled={loading || otp.length < 6} className="btn-primary">
                  {loading ? 'Verifying...' : 'Verify OTP'}
                </button>
                <button onClick={() => setOtpSent(false)} className="w-full text-xs text-gray-400 underline">
                  Resend OTP
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
