'use client';
import { useCartStore } from '@/store/cartStore';
import { BottomNav } from '@/components/layout/BottomNav';
import { Minus, Plus, Trash2, ArrowLeft, ShoppingBag } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import toast from 'react-hot-toast';

export default function CartPage() {
  const router = useRouter();
  const {
    items, updateQty, removeItem,
    subtotal, taxAmount, deliveryFee, discountAmt, total,
    coupon, removeCoupon,
  } = useCartStore();

  if (!items.length) {
    return (
      <div className="max-w-lg mx-auto min-h-screen bg-gray-50 flex flex-col items-center justify-center pb-20">
        <ShoppingBag size={64} className="text-gray-200 mb-4" />
        <h2 className="text-lg font-semibold text-gray-700 mb-1">Your cart is empty</h2>
        <p className="text-sm text-gray-400 mb-6">Add some delicious items!</p>
        <Link href="/" className="btn-primary max-w-xs text-center no-underline">Browse Menu</Link>
        <BottomNav />
      </div>
    );
  }

  return (
    <div className="max-w-lg mx-auto bg-gray-50 min-h-screen pb-20">
      {/* Header */}
      <div className="sticky top-0 bg-white border-b border-gray-100 px-4 py-3 flex items-center gap-3 z-10">
        <button onClick={() => router.back()} className="text-gray-600">
          <ArrowLeft size={20} />
        </button>
        <h1 className="text-base font-semibold">Your Cart</h1>
        <span className="ml-auto text-xs text-gray-400">{items.length} item{items.length > 1 ? 's' : ''}</span>
      </div>

      {/* Items */}
      <div className="px-4 pt-4 flex flex-col gap-3">
        {items.map((item) => (
          <div key={item.id} className="card p-3 flex items-center gap-3">
            <div className="w-14 h-14 rounded-xl bg-orange-50 flex items-center justify-center text-3xl flex-shrink-0">
              {item.emoji}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-900 truncate">{item.name}</p>
              <p className="text-xs text-gray-400 mt-0.5">₹{item.price} each</p>
            </div>
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => updateQty(item.id, item.quantity - 1)}
                className="w-7 h-7 rounded-lg bg-[#D85A30] text-white flex items-center justify-center"
              >
                <Minus size={12} />
              </button>
              <span className="text-sm font-semibold w-5 text-center">{item.quantity}</span>
              <button
                onClick={() => updateQty(item.id, item.quantity + 1)}
                className="w-7 h-7 rounded-lg bg-[#D85A30] text-white flex items-center justify-center"
              >
                <Plus size={12} />
              </button>
            </div>
            <div className="text-right min-w-[52px]">
              <p className="text-sm font-semibold text-gray-800">₹{item.price * item.quantity}</p>
              <button
                onClick={() => { removeItem(item.id); toast.success('Removed'); }}
                className="text-gray-300 hover:text-red-400 mt-0.5"
              >
                <Trash2 size={13} />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Bill Summary */}
      <div className="mx-4 mt-4 card p-4">
        <h3 className="text-sm font-semibold text-gray-700 mb-3">Bill summary</h3>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between text-gray-600">
            <span>Subtotal</span><span>₹{subtotal().toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-gray-600">
            <span>GST (5%)</span><span>₹{taxAmount().toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-gray-600">
            <span>Delivery fee</span>
            <span>{deliveryFee() === 0 ? <span className="text-green-600 font-medium">FREE</span> : `₹${deliveryFee()}`}</span>
          </div>
          {coupon && (
            <div className="flex justify-between text-green-600">
              <span className="flex items-center gap-1">
                Discount ({coupon.code})
                <button onClick={removeCoupon} className="text-red-400 text-xs ml-1">✕</button>
              </span>
              <span>−₹{discountAmt().toFixed(2)}</span>
            </div>
          )}
          <div className="border-t border-gray-100 pt-2 flex justify-between font-semibold text-gray-900">
            <span>Total</span><span>₹{total().toFixed(2)}</span>
          </div>
        </div>
      </div>

      {/* CTA */}
      <div className="px-4 mt-4">
        <Link href="/checkout" className="btn-primary flex items-center justify-center gap-2 no-underline text-white">
          Proceed to checkout — ₹{total().toFixed(2)}
        </Link>
      </div>

      <BottomNav />
    </div>
  );
}
