'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useCartStore } from '@/store/cartStore';
import { couponAPI } from '@/lib/api';
import { ArrowLeft, Truck, Store, MapPin, Tag } from 'lucide-react';
import toast from 'react-hot-toast';
import Link from 'next/link';

export default function CheckoutPage() {
  const router  = useRouter();
  const cart    = useCartStore();
  const [type, setType]       = useState<'delivery' | 'pickup'>('delivery');
  const [line1, setLine1]     = useState('');
  const [line2, setLine2]     = useState('');
  const [note, setNote]       = useState('');
  const [code, setCode]       = useState('');
  const [couponMsg, setCouponMsg] = useState('Try WELCOME20 for 20% off!');

  const applyCoupon = async () => {
    if (!code.trim()) return;
    try {
      const { data } = await couponAPI.validate(code.trim(), cart.subtotal());
      cart.setCoupon({ code: data.code, type: data.type, value: data.value, discount: cart.discountAmt() });
      setCouponMsg(`✅ ${data.code} applied — saved ₹${cart.discountAmt().toFixed(0)}!`);
      toast.success('Coupon applied!');
    } catch (e: any) {
      setCouponMsg('❌ ' + (e.response?.data?.error || 'Invalid coupon'));
    }
  };

  const SAVED_ADDRESSES = [
    { label: '🏠 Home', detail: 'Sector 18, Noida' },
    { label: '💼 Office', detail: 'Block B, Sector 62' },
  ];

  return (
    <div className="max-w-lg mx-auto bg-gray-50 min-h-screen pb-24">
      {/* Header */}
      <div className="sticky top-0 bg-white border-b border-gray-100 px-4 py-3 flex items-center gap-3 z-10">
        <button onClick={() => router.back()}><ArrowLeft size={20} className="text-gray-600" /></button>
        <h1 className="text-base font-semibold">Checkout</h1>
      </div>

      <div className="px-4 pt-4 space-y-4">
        {/* Delivery Toggle */}
        <div className="card p-4">
          <h2 className="text-sm font-semibold mb-3 text-gray-700">Delivery method</h2>
          <div className="flex gap-3">
            {(['delivery', 'pickup'] as const).map((t) => (
              <button
                key={t}
                onClick={() => setType(t)}
                className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl border text-sm font-medium transition-all ${
                  type === t ? 'bg-[#D85A30] text-white border-[#D85A30]' : 'bg-white text-gray-500 border-gray-200'
                }`}
              >
                {t === 'delivery' ? <Truck size={16} /> : <Store size={16} />}
                {t === 'delivery' ? 'Delivery' : 'Pickup'}
              </button>
            ))}
          </div>
        </div>

        {/* Address */}
        {type === 'delivery' && (
          <div className="card p-4">
            <h2 className="text-sm font-semibold mb-3 text-gray-700 flex items-center gap-2">
              <MapPin size={15} /> Delivery address
            </h2>
            <input
              className="input mb-2"
              placeholder="Flat, House no., Building"
              value={line1}
              onChange={(e) => setLine1(e.target.value)}
            />
            <input
              className="input mb-3"
              placeholder="Area, Street, Sector"
              value={line2}
              onChange={(e) => setLine2(e.target.value)}
            />
            <div className="flex flex-wrap gap-2">
              {SAVED_ADDRESSES.map((a) => (
                <button
                  key={a.label}
                  onClick={() => { setLine1(a.detail); toast.success('Address selected'); }}
                  className="chip chip-brand text-xs"
                >
                  {a.label} — {a.detail}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Special Instructions */}
        <div className="card p-4">
          <h2 className="text-sm font-semibold mb-3 text-gray-700">Special instructions</h2>
          <textarea
            className="input resize-none"
            rows={2}
            placeholder="E.g. less spicy, extra sauce, no onion..."
            value={note}
            onChange={(e) => setNote(e.target.value)}
          />
        </div>

        {/* Coupon */}
        <div className="card p-4">
          <h2 className="text-sm font-semibold mb-3 text-gray-700 flex items-center gap-2">
            <Tag size={15} /> Coupon code
          </h2>
          <div className="flex gap-2 mb-2">
            <input
              className="input flex-1"
              placeholder="Enter code"
              value={code}
              onChange={(e) => setCode(e.target.value.toUpperCase())}
            />
            <button
              onClick={applyCoupon}
              className="bg-[#D85A30] text-white px-4 py-2 rounded-xl text-sm font-medium hover:bg-[#993C1D]"
            >
              Apply
            </button>
          </div>
          <p className={`text-xs ${couponMsg.startsWith('✅') ? 'text-green-600' : couponMsg.startsWith('❌') ? 'text-red-500' : 'text-gray-400'}`}>
            {couponMsg}
          </p>
        </div>

        {/* Bill Summary */}
        <div className="card p-4">
          <h2 className="text-sm font-semibold mb-3 text-gray-700">Order summary</h2>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between text-gray-500"><span>Subtotal</span><span>₹{cart.subtotal().toFixed(2)}</span></div>
            <div className="flex justify-between text-gray-500"><span>GST (5%)</span><span>₹{cart.taxAmount().toFixed(2)}</span></div>
            <div className="flex justify-between text-gray-500">
              <span>Delivery</span>
              <span>{cart.deliveryFee() === 0 ? <span className="text-green-600 font-medium">FREE</span> : `₹${cart.deliveryFee()}`}</span>
            </div>
            {cart.coupon && (
              <div className="flex justify-between text-green-600">
                <span>Discount</span>
                <span>−₹{cart.discountAmt().toFixed(2)}</span>
              </div>
            )}
            <div className="border-t pt-2 flex justify-between font-semibold text-gray-900">
              <span>Total</span><span>₹{cart.total().toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* CTA */}
      <div className="fixed bottom-0 inset-x-0 bg-white border-t border-gray-100 px-4 py-3 max-w-lg mx-auto">
        <button
          onClick={() => {
            if (type === 'delivery' && !line1.trim()) { toast.error('Please enter delivery address'); return; }
            sessionStorage.setItem('checkout_data', JSON.stringify({ type, line1, line2, note }));
            router.push('/payment');
          }}
          className="btn-primary"
        >
          Proceed to payment — ₹{cart.total().toFixed(2)}
        </button>
      </div>
    </div>
  );
}
