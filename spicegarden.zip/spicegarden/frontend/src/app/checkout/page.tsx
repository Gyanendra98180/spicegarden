'use client';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useCartStore } from '@/store/cartStore';
import { ArrowLeft, Truck, Store, MapPin, Tag, ShoppingBag, CheckCircle } from 'lucide-react';
import toast from 'react-hot-toast';
import Link from 'next/link';

// ── Offline coupon validation (works without backend) ─────────
const COUPONS: Record<string, { type: string; value: number; min: number; max?: number; desc: string }> = {
  WELCOME20: { type: 'percent',       value: 20,  min: 100, max: 200, desc: '20% off your first order' },
  SPICE10:   { type: 'percent',       value: 10,  min: 200, max: 100, desc: '10% off all orders' },
  FLAT50:    { type: 'flat',          value: 50,  min: 400,            desc: '₹50 off on orders above ₹400' },
  FREEDEL:   { type: 'free_delivery', value: 40,  min: 300,            desc: 'Free delivery on orders above ₹300' },
};

const SAVED_ADDRESSES = [
  { label: '🏠 Home',   detail: 'Sector 18, Noida, UP 201301' },
  { label: '💼 Office', detail: 'Block B, Sector 62, Noida, UP 201309' },
];

export default function CheckoutPage() {
  const router = useRouter();
  const cart   = useCartStore();

  const [type,       setType]       = useState<'delivery' | 'pickup'>('delivery');
  const [line1,      setLine1]      = useState('');
  const [line2,      setLine2]      = useState('');
  const [city,       setCity]       = useState('');
  const [pincode,    setPincode]    = useState('');
  const [note,       setNote]       = useState('');
  const [code,       setCode]       = useState('');
  const [couponMsg,  setCouponMsg]  = useState('');
  const [couponOk,   setCouponOk]   = useState(false);
  const [mounted,    setMounted]    = useState(false);

  // Prevent SSR hydration mismatch
  useEffect(() => setMounted(true), []);

  // Redirect if cart is empty
  useEffect(() => {
    if (mounted && cart.items.length === 0) {
      router.replace('/');
    }
  }, [mounted, cart.items.length, router]);

  const subtotal    = mounted ? cart.subtotal()    : 0;
  const taxAmount   = mounted ? cart.taxAmount()   : 0;
  const deliveryFee = mounted ? cart.deliveryFee() : 40;
  const discountAmt = mounted ? cart.discountAmt() : 0;
  const total       = mounted ? cart.total()       : 0;

  // ── Coupon (fully offline) ──────────────────────────────────
  const applyCoupon = () => {
    const key = code.trim().toUpperCase();
    if (!key) { toast.error('Enter a coupon code'); return; }

    // Remove existing coupon first
    cart.removeCoupon();
    setCouponOk(false);

    const c = COUPONS[key];
    if (!c) {
      setCouponMsg('❌ Invalid coupon code');
      return;
    }
    if (subtotal < c.min) {
      setCouponMsg(`❌ Minimum order ₹${c.min} required`);
      return;
    }

    cart.setCoupon({ code: key, type: c.type, value: c.value, discount: 0 });
    setCouponOk(true);

    let saved = 0;
    if (c.type === 'percent')       saved = Math.min(subtotal * c.value / 100, c.max ?? Infinity);
    else if (c.type === 'flat')     saved = Math.min(c.value, subtotal);
    else if (c.type === 'free_delivery') saved = 40;

    setCouponMsg(`✅ ${key} applied — you save ₹${Math.round(saved)}!`);
    toast.success(`${c.desc}`);
  };

  const removeCoupon = () => {
    cart.removeCoupon();
    setCode('');
    setCouponMsg('');
    setCouponOk(false);
  };

  // ── Proceed to payment ──────────────────────────────────────
  const handleProceed = () => {
    if (type === 'delivery') {
      if (!line1.trim()) { toast.error('Enter flat / house number'); return; }
      if (!city.trim())  { toast.error('Enter city name'); return; }
      if (!pincode.trim() || pincode.length < 6) { toast.error('Enter valid 6-digit pincode'); return; }
    }

    // Save to localStorage (more reliable than sessionStorage on some browsers)
    try {
      localStorage.setItem('sg_checkout', JSON.stringify({ type, line1, line2, city, pincode, note }));
    } catch { /* ignore storage errors */ }

    router.push('/payment');
  };

  if (!mounted) return null;

  if (cart.items.length === 0) {
    return (
      <div className="max-w-lg mx-auto min-h-screen flex flex-col items-center justify-center gap-4 px-6">
        <ShoppingBag size={56} className="text-gray-200" />
        <p className="text-gray-500 text-sm">Your cart is empty</p>
        <Link href="/" className="btn-primary max-w-xs">Browse menu</Link>
      </div>
    );
  }

  return (
    <div className="max-w-lg mx-auto bg-gray-50 min-h-screen pb-32">

      {/* ── Header ─────────────────────────────────────────── */}
      <div className="sticky top-0 bg-white border-b border-gray-100 px-4 py-3 flex items-center gap-3 z-10">
        <button onClick={() => router.back()} className="p-1">
          <ArrowLeft size={20} className="text-gray-600" />
        </button>
        <h1 className="text-base font-semibold">Checkout</h1>
        <span className="ml-auto text-xs text-gray-400">{cart.items.length} item{cart.items.length > 1 ? 's' : ''}</span>
      </div>

      <div className="px-4 pt-4 space-y-4">

        {/* ── Items summary ───────────────────────────────── */}
        <div className="card p-4">
          <h2 className="text-sm font-semibold text-gray-700 mb-3">Your order</h2>
          {cart.items.map((item) => (
            <div key={item.id} className="flex items-center gap-2 py-1.5 border-b border-gray-50 last:border-0">
              <span className="text-xl">{item.emoji}</span>
              <span className="flex-1 text-sm text-gray-700">{item.name}</span>
              <span className="text-xs text-gray-400">×{item.quantity}</span>
              <span className="text-sm font-medium text-gray-800">₹{item.price * item.quantity}</span>
            </div>
          ))}
        </div>

        {/* ── Delivery method ─────────────────────────────── */}
        <div className="card p-4">
          <h2 className="text-sm font-semibold mb-3 text-gray-700">Delivery method</h2>
          <div className="flex gap-3">
            {(['delivery', 'pickup'] as const).map((t) => (
              <button
                key={t}
                onClick={() => setType(t)}
                className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl border text-sm font-medium transition-all ${
                  type === t
                    ? 'bg-[#D85A30] text-white border-[#D85A30]'
                    : 'bg-white text-gray-500 border-gray-200 hover:border-gray-300'
                }`}
              >
                {t === 'delivery' ? <Truck size={16} /> : <Store size={16} />}
                {t === 'delivery' ? '🛵 Delivery' : '🏪 Pickup'}
              </button>
            ))}
          </div>
          {type === 'pickup' && (
            <p className="mt-3 text-xs text-gray-500 bg-gray-50 rounded-lg p-2.5">
              📍 Pickup from: <strong>Spice Garden, Sector 18, Noida</strong><br />
              Ready in ~20 minutes
            </p>
          )}
        </div>

        {/* ── Delivery address ────────────────────────────── */}
        {type === 'delivery' && (
          <div className="card p-4">
            <h2 className="text-sm font-semibold mb-3 text-gray-700 flex items-center gap-2">
              <MapPin size={15} className="text-[#D85A30]" /> Delivery address
            </h2>

            {/* Saved address chips */}
            <div className="flex flex-wrap gap-2 mb-3">
              {SAVED_ADDRESSES.map((a) => (
                <button
                  key={a.label}
                  onClick={() => {
                    const parts = a.detail.split(', ');
                    setLine1(parts[0] || '');
                    setLine2(parts[1] || '');
                    setCity(parts[2]?.split(' ')[0] || 'Noida');
                    setPincode(parts[2]?.match(/\d{6}/)?.[0] || '201301');
                    toast.success('Address selected');
                  }}
                  className="chip chip-brand text-xs hover:bg-[#f0d5c8] transition-colors"
                >
                  {a.label}
                </button>
              ))}
            </div>

            <div className="space-y-2">
              <input
                className="input"
                placeholder="Flat / House no. / Building *"
                value={line1}
                onChange={(e) => setLine1(e.target.value)}
              />
              <input
                className="input"
                placeholder="Area / Street / Sector"
                value={line2}
                onChange={(e) => setLine2(e.target.value)}
              />
              <div className="flex gap-2">
                <input
                  className="input flex-1"
                  placeholder="City *"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                />
                <input
                  className="input w-32"
                  placeholder="Pincode *"
                  maxLength={6}
                  value={pincode}
                  onChange={(e) => setPincode(e.target.value.replace(/\D/g, ''))}
                />
              </div>
            </div>

            {line1 && city && pincode.length === 6 && (
              <div className="mt-3 flex items-center gap-2 text-green-600 text-xs bg-green-50 rounded-lg p-2">
                <CheckCircle size={14} />
                Delivering to: {line1}, {city} — {pincode}
              </div>
            )}
          </div>
        )}

        {/* ── Special instructions ────────────────────────── */}
        <div className="card p-4">
          <h2 className="text-sm font-semibold mb-2 text-gray-700">Special instructions</h2>
          <textarea
            className="input resize-none text-sm"
            rows={2}
            placeholder="E.g. less spicy, extra sauce, no onion..."
            value={note}
            onChange={(e) => setNote(e.target.value)}
          />
        </div>

        {/* ── Coupon code ─────────────────────────────────── */}
        <div className="card p-4">
          <h2 className="text-sm font-semibold mb-3 text-gray-700 flex items-center gap-2">
            <Tag size={15} className="text-[#D85A30]" /> Coupon code
          </h2>

          {couponOk ? (
            <div className="flex items-center gap-3 bg-green-50 border border-green-200 rounded-xl px-3 py-2.5">
              <CheckCircle size={16} className="text-green-600 flex-shrink-0" />
              <span className="text-sm text-green-700 flex-1 font-medium">{code}</span>
              <button onClick={removeCoupon} className="text-xs text-red-400 font-medium hover:text-red-600">
                Remove
              </button>
            </div>
          ) : (
            <div className="flex gap-2">
              <input
                className="input flex-1"
                placeholder="Enter coupon code"
                value={code}
                onChange={(e) => { setCode(e.target.value.toUpperCase()); setCouponMsg(''); }}
                onKeyDown={(e) => e.key === 'Enter' && applyCoupon()}
              />
              <button
                onClick={applyCoupon}
                className="bg-[#D85A30] text-white px-4 py-2 rounded-xl text-sm font-medium hover:bg-[#993C1D] active:scale-95 transition-all flex-shrink-0"
              >
                Apply
              </button>
            </div>
          )}

          {couponMsg && (
            <p className={`mt-2 text-xs font-medium ${couponOk ? 'text-green-600' : 'text-red-500'}`}>
              {couponMsg}
            </p>
          )}

          {!couponOk && (
            <div className="mt-2 flex flex-wrap gap-1.5">
              {Object.keys(COUPONS).map((c) => (
                <button
                  key={c}
                  onClick={() => { setCode(c); setCouponMsg(''); }}
                  className="text-[10px] bg-orange-50 text-[#D85A30] border border-orange-200 px-2 py-1 rounded-md font-medium hover:bg-orange-100"
                >
                  {c}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* ── Bill summary ─────────────────────────────────── */}
        <div className="card p-4">
          <h2 className="text-sm font-semibold mb-3 text-gray-700">Bill summary</h2>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between text-gray-500">
              <span>Subtotal ({cart.items.length} items)</span>
              <span>₹{subtotal.toFixed(0)}</span>
            </div>
            <div className="flex justify-between text-gray-500">
              <span>GST (5%)</span>
              <span>₹{taxAmount.toFixed(0)}</span>
            </div>
            {type === 'delivery' && (
              <div className="flex justify-between text-gray-500">
                <span>Delivery fee</span>
                <span>
                  {deliveryFee === 0
                    ? <span className="text-green-600 font-medium">FREE</span>
                    : `₹${deliveryFee}`
                  }
                </span>
              </div>
            )}
            {discountAmt > 0 && (
              <div className="flex justify-between text-green-600">
                <span>Discount ({cart.coupon?.code})</span>
                <span>−₹{discountAmt.toFixed(0)}</span>
              </div>
            )}
            {subtotal >= 500 && type === 'delivery' && (
              <p className="text-xs text-green-600 bg-green-50 rounded-lg px-2 py-1.5">
                🎉 Free delivery on orders above ₹500!
              </p>
            )}
            <div className="border-t border-gray-100 pt-2 mt-1 flex justify-between font-bold text-gray-900 text-base">
              <span>Total</span>
              <span className="text-[#D85A30]">₹{total.toFixed(0)}</span>
            </div>
          </div>
        </div>

        {/* Bottom spacer so content isn't hidden behind fixed button */}
        <div className="h-4" />
      </div>

      {/* ── Fixed bottom CTA ────────────────────────────────── */}
      <div className="fixed bottom-0 inset-x-0 z-20 bg-white border-t border-gray-100 px-4 py-3 max-w-lg mx-auto left-0 right-0">
        <button
          onClick={handleProceed}
          className="btn-primary flex items-center justify-center gap-2 text-base"
        >
          Proceed to payment
          <span className="font-bold">₹{total.toFixed(0)}</span>
          <span className="text-orange-200">→</span>
        </button>
        <p className="text-center text-xs text-gray-400 mt-1.5">
          🔒 Secure checkout · Free cancellation before delivery
        </p>
      </div>
    </div>
  );
}
