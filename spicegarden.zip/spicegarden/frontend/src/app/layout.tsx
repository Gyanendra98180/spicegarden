import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import { Providers } from '@/components/layout/Providers';
import './globals.css';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'Spice Garden — Authentic Indian Cuisine',
  description: 'Order authentic Indian food online. Fast delivery, easy payments.',
  manifest: '/manifest.json',
  themeColor: '#D85A30',
  openGraph: {
    title: 'Spice Garden',
    description: 'Authentic flavors, delivered to you',
    type: 'website',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
