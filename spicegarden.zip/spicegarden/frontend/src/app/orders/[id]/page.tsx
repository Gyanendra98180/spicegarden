'use client';
import { useQuery } from '@tanstack/react-query';
import { orderAPI } from '@/lib/api';
import { useParams, useRouter } from 'next/navigation';
import { ArrowLeft, CheckCircle2, Phone } from 'lucide-react';
import Link from 'next/link';
import { useEffect, useRef } from 'react';
import { io } from 'socket.io-client';
import { useQueryClient } from '@tanstack/react-query';

const STATUS_STEPS = [
  { key: 'pending',           label: 'Order placed',       desc: 'Your order is confirmed' },
  { key: 'confirmed',         label: 'Payment confirmed',  desc: 'We received your payment' },
  { key: 'preparing',         label: 'Preparing',          desc: 'Kitchen is working on your order' },
  { key: 'ready',             label: 'Ready',              desc: 'Food is ready!' },
  { key: 'out_for_delivery',  label: 'Out for delivery',   desc: 'Rider is on the way' },
  { key: 'delivered',         label: 'Delivered',          desc: 'Enjoy your meal! 🎉' },
];

const STATUS_ORDER = STATUS_STEPS.map((s) => s.key);

// ── Success Screen ────────────────────────────────────────────
export function SuccessScreen({ orderId }: { orderId: string }) {
  return (
    <div className="max-w-lg mx-auto bg-gray-50 min-h-screen flex flex-col items-center justify-center px-6 text-center pb-20">
      <CheckCircle2 size={72} className="text-[#D85A30] mb-5" />
      <h1 className="text-2xl font-bold text-gray-900 mb-2">Order placed! 🎉</h1>
      <p className="text-gray-500 text-sm mb-8">
        Your order is confirmed and the kitchen is getting started.<br />
        Estimated delivery: <strong>35–40 minutes</strong>
      </p>
      <Link href={`/orders/${orderId}`} className="btn-primary max-w-xs mb-3 flex items-center justify-center gap-2">
        Track order
      </Link>
      <Link href="/" className="btn-outline max-w-xs flex items-center justify-center">
        Back to home
      </Link>
    </div>
  );
}

// ── Tracking Screen ───────────────────────────────────────────
export default function OrderTrackingPage() {
  const { id }     = useParams<{ id: string }>();
  const router     = useRouter();
  const qc         = useQueryClient();

  const { data: order, isLoading } = useQuery({
    queryKey: ['order', id],
    queryFn:  () => orderAPI.get(id).then((r) => r.data),
    refetchInterval: 30_000,
  });

  // Real-time via socket
  useEffect(() => {
    const socket = io(process.env.NEXT_PUBLIC_SOCKET_URL!);
    socket.emit('join_order', id);
    socket.on('order_status', () => qc.invalidateQueries({ queryKey: ['order', id] }));
    return () => { socket.disconnect(); };
  }, [id, qc]);

  if (isLoading) return <div className="max-w-lg mx-auto p-8 text-center text-gray-400">Loading order...</div>;
  if (!order)    return <div className="max-w-lg mx-auto p-8 text-center text-gray-400">Order not found</div>;

  const currentIdx = STATUS_ORDER.indexOf(order.status);

  const STATUS_COLOR: Record<string, string> = {
    preparing:       'chip-amber',
    out_for_delivery:'chip-blue',
    delivered:       'chip-green',
    cancelled:       'chip-red',
    confirmed:       'chip-brand',
    pending:         'chip-brand',
  };

  return (
    <div className="max-w-lg mx-auto bg-gray-50 min-h-screen pb-10">
      {/* Header */}
      <div className="sticky top-0 bg-white border-b border-gray-100 px-4 py-3 flex items-center gap-3 z-10">
        <button onClick={() => router.push('/orders')}><ArrowLeft size={20} className="text-gray-600" /></button>
        <h1 className="text-base font-semibold">Track Order</h1>
      </div>

      {/* Order info */}
      <div className="px-4 py-4 bg-white border-b border-gray-100">
        <div className="flex justify-between items-center mb-1">
          <span className="font-semibold text-gray-800">Order #{order.order_number}</span>
          <span className={`chip ${STATUS_COLOR[order.status] || 'chip-brand'}`}>
            {order.status.replace(/_/g, ' ')}
          </span>
        </div>
        <p className="text-xs text-gray-400">
          {new Date(order.created_at).toLocaleString('en-IN')} · ₹{order.total_amount}
        </p>
      </div>

      {/* Status tracker */}
      <div className="px-4 py-5">
        {STATUS_STEPS.map((step, i) => {
          if (step.key === 'ready' && order.type === 'delivery') return null;
          const done   = i <= currentIdx;
          const active = i === currentIdx;
          const isLast = i === STATUS_STEPS.length - 1;
          return (
            <div key={step.key} className="flex gap-3 pb-5 last:pb-0">
              <div className="flex flex-col items-center">
                <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${
                  done ? 'bg-[#D85A30] border-[#D85A30] text-white' :
                  active ? 'bg-[#FAECE7] border-[#D85A30]' : 'bg-white border-gray-200'
                }`}>
                  {done && <span className="text-[9px] font-bold">✓</span>}
                  {active && !done && <span className="w-2 h-2 rounded-full bg-[#D85A30]" />}
                </div>
                {!isLast && <div className={`w-0.5 flex-1 mt-1 ${done ? 'bg-[#D85A30]' : 'bg-gray-200'}`} style={{ minHeight: 24 }} />}
              </div>
              <div className={`pb-1 ${!done && !active ? 'opacity-40' : ''}`}>
                <p className={`text-sm font-medium ${active ? 'text-[#D85A30]' : done ? 'text-gray-800' : 'text-gray-400'}`}>
                  {step.label}
                </p>
                <p className="text-xs text-gray-400 mt-0.5">{step.desc}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Order items */}
      <div className="mx-4 card p-4 mb-4">
        <h3 className="text-sm font-semibold text-gray-700 mb-3">Items ordered</h3>
        {order.items?.map((item: any) => (
          <div key={item.id} className="flex justify-between text-sm py-1.5 border-b border-gray-50 last:border-0">
            <span className="text-gray-700">{item.emoji} {item.item_snapshot?.name} × {item.quantity}</span>
            <span className="text-gray-500">₹{item.line_total}</span>
          </div>
        ))}
      </div>

      {/* Rider info (if out for delivery) */}
      {order.status === 'out_for_delivery' && (
        <div className="mx-4 card p-4">
          <h3 className="text-sm font-semibold text-gray-700 mb-3">Your rider</h3>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-orange-100 flex items-center justify-center text-2xl">🧑</div>
            <div className="flex-1">
              <p className="text-sm font-medium">Vikram Yadav</p>
              <p className="text-xs text-gray-400">⭐ 4.8 · Maruti Suzuki · DL01AA1234</p>
            </div>
            <button className="w-10 h-10 bg-[#D85A30] rounded-full flex items-center justify-center text-white">
              <Phone size={16} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
