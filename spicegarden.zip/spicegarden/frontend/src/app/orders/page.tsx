'use client';
import { useQuery } from '@tanstack/react-query';
import { orderAPI } from '@/lib/api';
import { BottomNav } from '@/components/layout/BottomNav';
import Link from 'next/link';
import { ClipboardList } from 'lucide-react';

const STATUS_CHIP: Record<string, string> = {
  pending:          'chip-amber',
  confirmed:        'chip-brand',
  preparing:        'chip-amber',
  ready:            'chip-blue',
  out_for_delivery: 'chip-blue',
  delivered:        'chip-green',
  cancelled:        'chip-red',
  refunded:         'chip-red',
};

export default function OrdersPage() {
  const { data: orders = [], isLoading } = useQuery({
    queryKey: ['orders'],
    queryFn:  () => orderAPI.list().then((r) => r.data),
  });

  return (
    <div className="max-w-lg mx-auto bg-gray-50 min-h-screen pb-20">
      <div className="sticky top-0 bg-white border-b border-gray-100 px-4 py-3 z-10">
        <h1 className="text-base font-semibold">My Orders</h1>
      </div>

      {isLoading ? (
        <div className="px-4 pt-4 space-y-3">
          {[1, 2, 3].map((i) => <div key={i} className="skeleton h-24 rounded-2xl" />)}
        </div>
      ) : orders.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-gray-400">
          <ClipboardList size={56} className="text-gray-200 mb-3" />
          <p className="text-sm">No orders yet</p>
          <Link href="/" className="btn-primary mt-4 max-w-xs">Order now</Link>
        </div>
      ) : (
        <div className="px-4 pt-4 space-y-3">
          {orders.map((order: any) => (
            <Link key={order.id} href={`/orders/${order.id}`} className="card p-4 block hover:shadow-md transition-shadow">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <p className="text-sm font-semibold text-gray-800">Order #{order.order_number}</p>
                  <p className="text-xs text-gray-400 mt-0.5">
                    {new Date(order.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                    {' · '}{order.item_count} item{order.item_count > 1 ? 's' : ''}
                  </p>
                </div>
                <span className={`chip ${STATUS_CHIP[order.status] || 'chip-brand'} capitalize`}>
                  {order.status.replace(/_/g, ' ')}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-gray-800">₹{order.total_amount}</span>
                <span className="text-xs text-[#D85A30] font-medium">
                  {['preparing', 'out_for_delivery', 'confirmed'].includes(order.status) ? 'Track →' : 'View details →'}
                </span>
              </div>
            </Link>
          ))}
        </div>
      )}

      <BottomNav />
    </div>
  );
}
