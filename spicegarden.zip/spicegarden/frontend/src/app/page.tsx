import { BottomNav } from '@/components/layout/BottomNav';
import { HeroBanner } from '@/components/menu/HeroBanner';
import { CategoryStrip } from '@/components/menu/CategoryStrip';
import { MenuGrid } from '@/components/menu/MenuGrid';
import { PromoBanner } from '@/components/menu/PromoBanner';

export default function HomePage() {
  return (
    <div className="max-w-lg mx-auto bg-gray-50 min-h-screen pb-20">
      <HeroBanner />
      <PromoBanner />
      <CategoryStrip />
      <MenuGrid />
      <BottomNav />
    </div>
  );
}
