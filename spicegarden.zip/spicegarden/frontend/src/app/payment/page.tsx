'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useCartStore } from '@/store/cartStore';
import { orderAPI, paymentAPI } from '@/lib/api';
import { ArrowLeft, Shield, Smartphone, CreditCard, Wallet, Banknote } from 'lucide-react';
import toast from 'react-hot-toast';
import clsx from 'clsx';

type PayMethod = 'upi' | 'card' | 'wallet' | 'cod';

const METHODS = [
  { id: 'upi',    label: 'UPI',                sub: 'GPay, PhonePe, Paytm',     Icon: Smartphone,  color: 'bg-blue-50' },
  { id: 'card',   label: 'Card',               sub: 'Visa, Mastercard, RuPay',  Icon: CreditCard,  color: 'bg-green-50' },
  { id: 'wallet', label: 'Wallet',             sub: 'Paytm, Amazon Pay',        Icon: Wallet,      color: 'bg-amber-50' },
  { id: 'cod',    label: 'Cash on delivery',   sub: 'Pay when delivered',       Icon: Banknote,    color: 'bg-orange-50' },
] as const;

declare global { interface Window { Razorpay: any } }

export default function PaymentPage() {
  const router   = useRouter();
  const cart     = useCartStore();
  const [method, setMethod] = useState<PayMethod>('upi');
  const [upiId, setUpiId]   = useState('');
  const [loading, setLoading] = useState(false);

  const loadRazorpay = () =>
    new Promise<boolean>((resolve) => {
      if (window.Razorpay) return resolve(true);
      const s  = document.createElement('script');
      s.src    = 'https://checkout.razorpay.com/v1/checkout.js';
      s.onload = () => resolve(true);
      s.onerror = () => resolve(false);
      document.body.appendChild(s);
    });

  const handlePay = async () => {
    setLoading(true);
    try {
      const checkoutData = JSON.parse(localStorage.getItem('sg_checkout') || '{}');

      // 1. Create order
      const { data: { order } } = await orderAPI.create({
        items: cart.items.map((i) => ({ item_id: i.id, quantity: i.quantity })),
        type:  checkoutData.type || 'delivery',
        delivery_address: checkoutData.line1
          ? { line1: checkoutData.line1, line2: checkoutData.line2 }
          : undefined,
        special_instructions: checkoutData.note,
        coupon_code: cart.coupon?.code,
      });

      if (method === 'cod') {
        cart.clearCart();
        router.push(`/orders/${order.id}/success`);
        return;
      }

      // 2. Create Razorpay order
      const { data: rzpData } = await paymentAPI.createOrder({
        order_id: order.id,
        method,
      });

      // 3. Load Razorpay SDK
      const ok = await loadRazorpay();
      if (!ok) throw new Error('Failed to load Razorpay');

      // 4. Open checkout
      await new Promise<void>((resolve, reject) => {
        const rzp = new window.Razorpay({
          key:         rzpData.key_id,
          amount:      rzpData.amount,
          currency:    'INR',
          order_id:    rzpData.razorpay_order_id,
          name:        'Spice Garden',
          description: `Order #${order.order_number}`,
          image:       '/logo.png',
          prefill: { contact: '', email: '' },
          theme:   { color: '#D85A30' },
          handler: async (response: any) => {
            try {
              await paymentAPI.verify({
                razorpay_order_id:   response.razorpay_order_id,
                razorpay_payment_id: response.razorpay_payment_id,
                razorpay_signature:  response.razorpay_signature,
                payment_id:          rzpData.payment_id,
              });
              cart.clearCart();
              router.push(`/orders/${order.id}/success`);
              resolve();
            } catch { reject(new Error('Payment verification failed')); }
          },
          modal: { ondismiss: () => reject(new Error('Payment cancelled')) },
        });
        rzp.open();
      });
    } catch (err: any) {
      toast.error(err.message || 'Payment failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-lg mx-auto bg-gray-50 min-h-screen pb-24">
      <div className="sticky top-0 bg-white border-b border-gray-100 px-4 py-3 flex items-center gap-3 z-10">
        <button onClick={() => router.back()}><ArrowLeft size={20} className="text-gray-600" /></button>
        <h1 className="text-base font-semibold">Payment</h1>
      </div>

      <div className="px-4 pt-4 space-y-3">
        {/* Amount card */}
        <div className="card p-4 text-center">
          <p className="text-sm text-gray-500 mb-1">Amount to pay</p>
          <p className="text-3xl font-bold text-[#D85A30]">₹{cart.total().toFixed(2)}</p>
        </div>

        {/* Methods */}
        <div className="card p-4">
          <h2 className="text-sm font-semibold text-gray-700 mb-3">Choose payment method</h2>
          <div className="space-y-2">
            {METHODS.map(({ id, label, sub, Icon, color }) => (
              <button
                key={id}
                onClick={() => setMethod(id as PayMethod)}
                className={clsx(
                  'w-full flex items-center gap-3 p-3 rounded-xl border transition-all text-left',
                  method === id ? 'border-[#D85A30] bg-[#FAECE7]' : 'border-gray-100 bg-white'
                )}
              >
                <div className={`w-10 h-10 ${color} rounded-xl flex items-center justify-center flex-shrink-0`}>
                  <Icon size={20} className="text-gray-600" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-800">{label}</p>
                  <p className="text-xs text-gray-400">{sub}</p>
                </div>
                <div className={clsx(
                  'w-4 h-4 rounded-full border-2 flex items-center justify-center flex-shrink-0',
                  method === id ? 'border-[#D85A30]' : 'border-gray-300'
                )}>
                  {method === id && <div className="w-2 h-2 bg-[#D85A30] rounded-full" />}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* UPI ID input */}
        {method === 'upi' && (
          <div className="card p-4">
            <h2 className="text-sm font-semibold text-gray-700 mb-2">UPI ID</h2>
            <input
              className="input"
              placeholder="yourname@upi"
              value={upiId}
              onChange={(e) => setUpiId(e.target.value)}
            />
          </div>
        )}

        {/* Security badge */}
        <div className="flex items-center justify-center gap-2 text-xs text-gray-400 py-2">
          <Shield size={14} />
          Secured by Razorpay · 256-bit SSL
        </div>
      </div>

      <div className="fixed bottom-0 inset-x-0 bg-white border-t border-gray-100 px-4 py-3 max-w-lg mx-auto">
        <button onClick={handlePay} disabled={loading} className="btn-primary flex items-center justify-center gap-2">
          {loading ? (
            <><span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />Processing...</>
          ) : (
            method === 'cod' ? 'Place order (Cash on delivery)' : `Pay ₹${cart.total().toFixed(2)}`
          )}
        </button>
      </div>
    </div>
  );
}
