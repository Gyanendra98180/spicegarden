'use client';
import { useAuthStore } from '@/store/authStore';
import { BottomNav } from '@/components/layout/BottomNav';
import { ChevronRight, Package, MapPin, CreditCard, Gift, HelpCircle, Settings, LogOut, ShieldCheck } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import toast from 'react-hot-toast';

const MENU_ITEMS = [
  { icon: Package,     label: 'My orders',         href: '/orders' },
  { icon: MapPin,      label: 'Saved addresses',    href: '/profile/addresses' },
  { icon: CreditCard,  label: 'Payment methods',    href: '/profile/payments' },
  { icon: Gift,        label: 'Coupons & offers',   href: '/profile/coupons' },
  { icon: HelpCircle,  label: 'Help & support',     href: '/support' },
  { icon: Settings,    label: 'Account settings',   href: '/profile/settings' },
  { icon: ShieldCheck, label: 'Admin panel',        href: '/admin', adminOnly: true },
];

export default function ProfilePage() {
  const { user, logout } = useAuthStore();
  const router           = useRouter();

  const handleLogout = async () => {
    await logout();
    toast.success('Logged out');
    router.push('/auth/login');
  };

  if (!user) {
    return (
      <div className="max-w-lg mx-auto bg-gray-50 min-h-screen flex flex-col items-center justify-center px-6 pb-20">
        <div className="text-5xl mb-4">👤</div>
        <h2 className="text-lg font-semibold mb-2">Sign in to your account</h2>
        <p className="text-sm text-gray-400 mb-6 text-center">Access your orders, saved addresses and more</p>
        <Link href="/auth/login" className="btn-primary max-w-xs">Login / Sign up</Link>
        <BottomNav />
      </div>
    );
  }

  return (
    <div className="max-w-lg mx-auto bg-gray-50 min-h-screen pb-20">
      <div className="sticky top-0 bg-white border-b border-gray-100 px-4 py-3 z-10">
        <h1 className="text-base font-semibold">Profile</h1>
      </div>

      {/* User card */}
      <div className="px-4 pt-4 mb-4">
        <div className="card p-4 flex items-center gap-4">
          <div className="w-14 h-14 rounded-full bg-[#D85A30] flex items-center justify-center text-white text-xl font-bold">
            {user.name?.[0]?.toUpperCase()}
          </div>
          <div>
            <p className="font-semibold text-gray-900">{user.name}</p>
            <p className="text-xs text-gray-400 mt-0.5">{user.email || user.phone}</p>
            {user.is_verified && (
              <span className="chip chip-green text-[10px] mt-1">Verified</span>
            )}
          </div>
        </div>
      </div>

      {/* Menu */}
      <div className="px-4 space-y-2">
        {MENU_ITEMS.filter((m) => !m.adminOnly || user.role === 'admin').map(({ icon: Icon, label, href, adminOnly }) => (
          <Link
            key={href}
            href={href}
            className={`card px-4 py-3.5 flex items-center gap-3 hover:shadow-md transition-shadow ${adminOnly ? 'border-[#D85A30]/20' : ''}`}
          >
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${adminOnly ? 'bg-[#FAECE7]' : 'bg-gray-50'}`}>
              <Icon size={18} className={adminOnly ? 'text-[#D85A30]' : 'text-gray-500'} />
            </div>
            <span className={`text-sm font-medium flex-1 ${adminOnly ? 'text-[#D85A30]' : 'text-gray-700'}`}>{label}</span>
            <ChevronRight size={16} className="text-gray-300" />
          </Link>
        ))}

        {/* Logout */}
        <button
          onClick={handleLogout}
          className="card w-full px-4 py-3.5 flex items-center gap-3 hover:shadow-md transition-shadow"
        >
          <div className="w-9 h-9 rounded-xl bg-red-50 flex items-center justify-center flex-shrink-0">
            <LogOut size={18} className="text-red-500" />
          </div>
          <span className="text-sm font-medium text-red-500 flex-1 text-left">Logout</span>
          <ChevronRight size={16} className="text-gray-300" />
        </button>
      </div>

      <BottomNav />
    </div>
  );
}
