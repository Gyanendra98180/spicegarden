'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Home, UtensilsCrossed, ClipboardList, User, ShoppingCart } from 'lucide-react';
import { useCartStore } from '@/store/cartStore';
import clsx from 'clsx';

const NAV = [
  { href: '/',        label: 'Home',   Icon: Home },
  { href: '/menu',    label: 'Menu',   Icon: UtensilsCrossed },
  { href: '/cart',    label: 'Cart',   Icon: ShoppingCart },
  { href: '/orders',  label: 'Orders', Icon: ClipboardList },
  { href: '/profile', label: 'Profile',Icon: User },
];

export function BottomNav() {
  const path     = usePathname();
  const itemCount = useCartStore((s) => s.itemCount());

  return (
    <nav className="fixed bottom-0 inset-x-0 bg-white border-t border-gray-100 z-50 safe-bottom">
      <div className="max-w-lg mx-auto flex">
        {NAV.map(({ href, label, Icon }) => {
          const active = path === href || (href !== '/' && path.startsWith(href));
          return (
            <Link
              key={href}
              href={href}
              className={clsx(
                'flex-1 flex flex-col items-center gap-0.5 py-2.5 text-[11px] font-medium transition-colors',
                active ? 'text-[#D85A30]' : 'text-gray-400 hover:text-gray-600'
              )}
            >
              <span className="relative">
                <Icon size={22} strokeWidth={active ? 2 : 1.5} />
                {label === 'Cart' && itemCount > 0 && (
                  <span className="absolute -top-1 -right-1.5 bg-[#D85A30] text-white text-[9px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
                    {itemCount > 9 ? '9+' : itemCount}
                  </span>
                )}
              </span>
              {label}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
