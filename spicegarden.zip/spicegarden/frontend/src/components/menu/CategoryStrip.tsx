'use client';
import { useQuery } from '@tanstack/react-query';
import { menuAPI } from '@/lib/api';
import { useRouter, useSearchParams } from 'next/navigation';
import clsx from 'clsx';

const EMOJI: Record<string, string> = {
  starters:    '🥗',
  'main-course': '🍛',
  breads:      '🫓',
  desserts:    '🍮',
  beverages:   '🥤',
};

export function CategoryStrip() {
  const router = useRouter();
  const params = useSearchParams();
  const active = params.get('category') || 'all';

  const { data: cats = [] } = useQuery({
    queryKey: ['categories'],
    queryFn:  () => menuAPI.getCategories().then((r) => r.data),
  });

  const go = (slug: string) => {
    const url = slug === 'all' ? '/' : `/?category=${slug}`;
    router.push(url);
  };

  return (
    <div className="mt-5 px-4">
      <h2 className="text-sm font-semibold text-gray-500 uppercase tracking-wide mb-3">Categories</h2>
      <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
        <button
          onClick={() => go('all')}
          className={clsx(
            'flex-shrink-0 flex flex-col items-center gap-1 px-4 py-2.5 rounded-2xl text-xs font-medium border transition-all',
            active === 'all'
              ? 'bg-[#D85A30] text-white border-[#D85A30]'
              : 'bg-white text-gray-600 border-gray-100'
          )}
        >
          <span className="text-xl">🍽</span>
          All
        </button>
        {cats.map((cat: any) => (
          <button
            key={cat.slug}
            onClick={() => go(cat.slug)}
            className={clsx(
              'flex-shrink-0 flex flex-col items-center gap-1 px-4 py-2.5 rounded-2xl text-xs font-medium border transition-all',
              active === cat.slug
                ? 'bg-[#D85A30] text-white border-[#D85A30]'
                : 'bg-white text-gray-600 border-gray-100'
            )}
          >
            <span className="text-xl">{EMOJI[cat.slug] || '🍽'}</span>
            {cat.name}
          </button>
        ))}
      </div>
    </div>
  );
}
