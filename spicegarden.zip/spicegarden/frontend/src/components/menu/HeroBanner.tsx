'use client';
import { ShoppingCart, MapPin, Search } from 'lucide-react';
import Link from 'next/link';
import { useCartStore } from '@/store/cartStore';
import { useRouter } from 'next/navigation';
import { useState } from 'react';

export function HeroBanner() {
  const itemCount = useCartStore((s) => s.itemCount());
  const router    = useRouter();
  const [q, setQ] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (q.trim()) router.push(`/menu?search=${encodeURIComponent(q.trim())}`);
  };

  return (
    <header className="bg-[#D85A30] text-white px-4 pt-12 pb-6">
      <div className="flex items-start justify-between mb-5">
        <div>
          <div className="flex items-center gap-1 text-orange-200 text-xs mb-1">
            <MapPin size={12} />
            Delivering to
          </div>
          <button className="text-white font-semibold text-base flex items-center gap-1">
            Sector 18, Noida
            <span className="text-orange-200">▾</span>
          </button>
        </div>
        <Link
          href="/cart"
          className="relative bg-white/20 rounded-full w-10 h-10 flex items-center justify-center"
        >
          <ShoppingCart size={20} />
          {itemCount > 0 && (
            <span className="absolute -top-1 -right-1 bg-white text-[#D85A30] text-[10px] font-bold rounded-full w-5 h-5 flex items-center justify-center">
              {itemCount}
            </span>
          )}
        </Link>
      </div>

      <div className="mb-1">
        <h1 className="text-xl font-semibold leading-snug">
          Authentic flavors,<br />delivered to you 🍽
        </h1>
      </div>

      <form onSubmit={handleSearch} className="mt-4 relative">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search dishes or categories..."
          className="w-full bg-white text-gray-800 rounded-xl pl-9 pr-4 py-2.5 text-sm focus:outline-none"
        />
      </form>
    </header>
  );
}
