'use client';
import { useQuery } from '@tanstack/react-query';
import { useSearchParams } from 'next/navigation';
import { menuAPI } from '@/lib/api';
import { useCartStore } from '@/store/cartStore';
import { Star, Plus, Minus } from 'lucide-react';
import toast from 'react-hot-toast';
import clsx from 'clsx';

export function MenuGrid() {
  const params   = useSearchParams();
  const category = params.get('category') || undefined;
  const search   = params.get('search')   || undefined;

  const { data, isLoading } = useQuery({
    queryKey: ['menu-items', category, search],
    queryFn:  () => menuAPI.getItems({ category, search, limit: 50 }).then((r) => r.data),
  });

  const { items: cartItems, addItem, updateQty } = useCartStore();

  const getQty = (id: string) => cartItems.find((i) => i.id === id)?.quantity || 0;

  const handleAdd = (item: any) => {
    addItem({ id: item.id, name: item.name, price: Number(item.price), emoji: item.emoji, image_url: item.image_url });
    toast.success(`${item.name} added!`);
  };

  if (isLoading) {
    return (
      <div className="px-4 mt-5 grid grid-cols-1 gap-3">
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="skeleton h-28 rounded-2xl" />
        ))}
      </div>
    );
  }

  const items = data?.items || [];

  if (!items.length) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-gray-400">
        <span className="text-5xl mb-3">🔍</span>
        <p className="text-sm">No items found</p>
      </div>
    );
  }

  // Group by category
  const grouped: Record<string, any[]> = {};
  items.forEach((item: any) => {
    const cat = item.category_name;
    if (!grouped[cat]) grouped[cat] = [];
    grouped[cat].push(item);
  });

  return (
    <div className="px-4 mt-5 pb-4">
      {Object.entries(grouped).map(([cat, catItems]) => (
        <div key={cat} className="mb-6">
          <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wide mb-3">{cat}</h3>
          <div className="flex flex-col gap-3">
            {catItems.map((item: any) => {
              const qty = getQty(item.id);
              return (
                <div
                  key={item.id}
                  className={clsx('card p-3 flex gap-3', !item.is_available && 'opacity-50')}
                >
                  {/* Image / Emoji */}
                  <div className="w-20 h-20 rounded-xl bg-orange-50 flex items-center justify-center text-4xl flex-shrink-0 overflow-hidden">
                    {item.image_url
                      ? <img src={item.image_url} alt={item.name} className="w-full h-full object-cover" />
                      : item.emoji
                    }
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start gap-1 mb-0.5">
                      {/* Veg dot */}
                      <span className={clsx(
                        'mt-1 flex-shrink-0 w-3 h-3 rounded-sm border-2 flex items-center justify-center',
                        item.is_veg ? 'border-green-600' : 'border-red-600'
                      )}>
                        <span className={clsx('w-1.5 h-1.5 rounded-full', item.is_veg ? 'bg-green-600' : 'bg-red-600')} />
                      </span>
                      <span className="text-sm font-medium text-gray-900 leading-tight">{item.name}</span>
                    </div>

                    {item.avg_rating && (
                      <div className="flex items-center gap-1 mb-1">
                        <Star size={11} className="fill-amber-400 text-amber-400" />
                        <span className="text-xs text-gray-500">{item.avg_rating}</span>
                        {item.prep_time_mins && (
                          <span className="text-xs text-gray-400 ml-1">· {item.prep_time_mins} min</span>
                        )}
                      </div>
                    )}

                    <p className="text-xs text-gray-400 leading-relaxed line-clamp-2 mb-2">{item.description}</p>

                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-[#D85A30] font-semibold text-sm">₹{item.price}</span>
                        {item.compare_price && (
                          <span className="text-xs text-gray-400 line-through ml-1.5">₹{item.compare_price}</span>
                        )}
                      </div>

                      {!item.is_available ? (
                        <span className="text-xs text-red-400 font-medium">Unavailable</span>
                      ) : qty === 0 ? (
                        <button
                          onClick={() => handleAdd(item)}
                          className="bg-[#D85A30] text-white text-sm font-semibold px-4 py-1.5 rounded-lg flex items-center gap-1 hover:bg-[#993C1D] transition-colors"
                        >
                          <Plus size={14} /> Add
                        </button>
                      ) : (
                        <div className="flex items-center gap-2 bg-[#D85A30] rounded-lg px-2 py-1">
                          <button onClick={() => updateQty(item.id, qty - 1)} className="text-white">
                            <Minus size={14} />
                          </button>
                          <span className="text-white text-sm font-semibold min-w-[16px] text-center">{qty}</span>
                          <button onClick={() => updateQty(item.id, qty + 1)} className="text-white">
                            <Plus size={14} />
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}
