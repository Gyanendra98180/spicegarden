'use client';
import { Tag } from 'lucide-react';

const PROMOS = [
  { code: 'WELCOME20', text: '20% off your first order', sub: 'New customers only' },
  { code: 'SPICE10',   text: '10% off all orders',       sub: 'Min. order ₹200' },
  { code: 'FREEDEL',   text: 'Free delivery',             sub: 'Orders above ₹300' },
];

export function PromoBanner() {
  return (
    <div className="px-4 mt-4">
      <div className="flex gap-3 overflow-x-auto no-scrollbar pb-1">
        {PROMOS.map((p) => (
          <div
            key={p.code}
            className="min-w-[220px] bg-gradient-to-r from-[#D85A30] to-[#993C1D] text-white rounded-2xl p-3.5 flex items-center gap-3"
          >
            <div className="bg-white/20 rounded-lg p-2">
              <Tag size={18} />
            </div>
            <div>
              <p className="font-semibold text-sm">{p.text}</p>
              <p className="text-orange-200 text-xs">{p.sub}</p>
              <span className="inline-block mt-1 bg-white/20 text-white text-xs font-bold px-2 py-0.5 rounded-md tracking-wide">
                {p.code}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
