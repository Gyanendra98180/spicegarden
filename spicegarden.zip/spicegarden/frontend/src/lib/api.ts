import axios from 'axios';

const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL,
  withCredentials: true,
});

// Attach access token
api.interceptors.request.use((config) => {
  if (typeof window !== 'undefined') {
    const token = localStorage.getItem('access_token');
    if (token) config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Auto-refresh on 401
let refreshing = false;
let queue: Array<(token: string) => void> = [];

api.interceptors.response.use(
  (res) => res,
  async (err) => {
    const original = err.config;
    if (err.response?.status !== 401 || original._retry) return Promise.reject(err);

    if (refreshing) {
      return new Promise((resolve) => {
        queue.push((token) => {
          original.headers.Authorization = `Bearer ${token}`;
          resolve(api(original));
        });
      });
    }

    original._retry = true;
    refreshing = true;

    try {
      const refresh_token = localStorage.getItem('refresh_token');
      if (!refresh_token) throw new Error('No refresh token');

      const { data } = await axios.post(`${process.env.NEXT_PUBLIC_API_URL}/auth/refresh`, { refresh_token });
      localStorage.setItem('access_token', data.access_token);
      queue.forEach((cb) => cb(data.access_token));
      queue = [];
      original.headers.Authorization = `Bearer ${data.access_token}`;
      return api(original);
    } catch {
      localStorage.removeItem('access_token');
      localStorage.removeItem('refresh_token');
      window.location.href = '/auth/login';
      return Promise.reject(err);
    } finally {
      refreshing = false;
    }
  }
);

export default api;

// ── Auth ──────────────────────────────────────────────────────
export const authAPI = {
  signup:    (d: any)  => api.post('/auth/signup', d),
  login:     (d: any)  => api.post('/auth/login', d),
  sendOTP:   (d: any)  => api.post('/auth/send-otp', d),
  verifyOTP: (d: any)  => api.post('/auth/verify-otp', d),
  refresh:   (d: any)  => api.post('/auth/refresh', d),
  logout:    (d: any)  => api.post('/auth/logout', d),
  me:        ()        => api.get('/auth/me'),
  updateMe:  (d: any)  => api.patch('/auth/me', d),
};

// ── Menu ──────────────────────────────────────────────────────
export const menuAPI = {
  getCategories: ()         => api.get('/menu/categories'),
  getItems:      (p: any)   => api.get('/menu/items', { params: p }),
  getItem:       (slug: string) => api.get(`/menu/items/${slug}`),
  createItem:    (d: any)   => api.post('/menu/items', d),
  updateItem:    (id: string, d: any) => api.patch(`/menu/items/${id}`, d),
  deleteItem:    (id: string) => api.delete(`/menu/items/${id}`),
};

// ── Orders ────────────────────────────────────────────────────
export const orderAPI = {
  create:       (d: any)   => api.post('/orders', d),
  list:         (p?: any)  => api.get('/orders', { params: p }),
  get:          (id: string) => api.get(`/orders/${id}`),
  updateStatus: (id: string, d: any) => api.patch(`/orders/${id}/status`, d),
};

// ── Payments ──────────────────────────────────────────────────
export const paymentAPI = {
  createOrder: (d: any) => api.post('/payments/create-order', d),
  verify:      (d: any) => api.post('/payments/verify', d),
  refund:      (id: string, d: any) => api.post(`/payments/${id}/refund`, d),
};

// ── Coupons ───────────────────────────────────────────────────
export const couponAPI = {
  validate: (code: string, amount: number) =>
    api.post('/coupons/validate', { code, amount }),
};

// ── Addresses ─────────────────────────────────────────────────
export const addressAPI = {
  list:   ()              => api.get('/addresses'),
  create: (d: any)        => api.post('/addresses', d),
  update: (id: string, d: any) => api.patch(`/addresses/${id}`, d),
  delete: (id: string)    => api.delete(`/addresses/${id}`),
};

// ── Reviews ───────────────────────────────────────────────────
export const reviewAPI = {
  create: (d: any) => api.post('/reviews', d),
  list:   (itemId: string) => api.get(`/reviews?item_id=${itemId}`),
};

// ── Admin ─────────────────────────────────────────────────────
export const adminAPI = {
  dashboard: () => api.get('/admin/dashboard'),
  reports:   (p: any) => api.get('/admin/reports', { params: p }),
  orders:    (p?: any) => api.get('/admin/orders', { params: p }),
  users:     () => api.get('/admin/users'),
};
