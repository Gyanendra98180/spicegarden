import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { authAPI } from '@/lib/api';

export interface User {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  role: 'customer' | 'admin' | 'staff';
  avatar_url?: string;
  is_verified: boolean;
}

interface AuthStore {
  user:         User | null;
  accessToken:  string | null;
  refreshToken: string | null;
  isLoading:    boolean;

  setTokens: (access: string, refresh: string) => void;
  setUser:   (user: User) => void;
  logout:    () => Promise<void>;
  fetchMe:   () => Promise<void>;
}

export const useAuthStore = create<AuthStore>()(
  persist(
    (set, get) => ({
      user:         null,
      accessToken:  null,
      refreshToken: null,
      isLoading:    false,

      setTokens: (access, refresh) => {
        localStorage.setItem('access_token', access);
        localStorage.setItem('refresh_token', refresh);
        set({ accessToken: access, refreshToken: refresh });
      },

      setUser: (user) => set({ user }),

      logout: async () => {
        try {
          const rt = get().refreshToken;
          if (rt) await authAPI.logout({ refresh_token: rt });
        } catch {}
        localStorage.removeItem('access_token');
        localStorage.removeItem('refresh_token');
        set({ user: null, accessToken: null, refreshToken: null });
      },

      fetchMe: async () => {
        set({ isLoading: true });
        try {
          const { data } = await authAPI.me();
          set({ user: data });
        } catch {
          set({ user: null });
        } finally {
          set({ isLoading: false });
        }
      },
    }),
    {
      name: 'spicegarden-auth',
      partialize: (s) => ({ accessToken: s.accessToken, refreshToken: s.refreshToken, user: s.user }),
    }
  )
);
