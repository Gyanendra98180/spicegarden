import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface CartItem {
  id: string;
  name: string;
  price: number;
  emoji: string;
  image_url?: string;
  quantity: number;
  customizations?: Record<string, string>;
}

interface CartStore {
  items: CartItem[];
  coupon: { code: string; type: string; value: number; discount: number } | null;

  addItem:       (item: Omit<CartItem, 'quantity'>) => void;
  removeItem:    (id: string) => void;
  updateQty:     (id: string, qty: number) => void;
  clearCart:     () => void;
  setCoupon:     (c: CartStore['coupon']) => void;
  removeCoupon:  () => void;

  // Computed
  subtotal:      () => number;
  taxAmount:     () => number;
  deliveryFee:   () => number;
  discountAmt:   () => number;
  total:         () => number;
  itemCount:     () => number;
}

export const useCartStore = create<CartStore>()(
  persist(
    (set, get) => ({
      items:  [],
      coupon: null,

      addItem: (item) => set((s) => {
        const existing = s.items.find((i) => i.id === item.id);
        if (existing) {
          return { items: s.items.map((i) => i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i) };
        }
        return { items: [...s.items, { ...item, quantity: 1 }] };
      }),

      removeItem: (id) => set((s) => ({ items: s.items.filter((i) => i.id !== id) })),

      updateQty: (id, qty) => set((s) => {
        if (qty <= 0) return { items: s.items.filter((i) => i.id !== id) };
        return { items: s.items.map((i) => i.id === id ? { ...i, quantity: qty } : i) };
      }),

      clearCart:    () => set({ items: [], coupon: null }),
      setCoupon:    (c) => set({ coupon: c }),
      removeCoupon: () => set({ coupon: null }),

      subtotal:    () => get().items.reduce((sum, i) => sum + i.price * i.quantity, 0),
      taxAmount:   () => Math.round(get().subtotal() * 0.05 * 100) / 100,
      deliveryFee: () => {
        const sub = get().subtotal();
        if (get().coupon?.type === 'free_delivery') return 0;
        return sub >= 500 ? 0 : 40;
      },
      discountAmt: () => {
        const c = get().coupon;
        if (!c) return 0;
        const sub = get().subtotal();
        if (c.type === 'percent') return Math.round(sub * c.value / 100 * 100) / 100;
        if (c.type === 'flat') return Math.min(c.value, sub);
        if (c.type === 'free_delivery') return 40;
        return 0;
      },
      total: () => {
        const s = get();
        return Math.round((s.subtotal() + s.taxAmount() + s.deliveryFee() - s.discountAmt()) * 100) / 100;
      },
      itemCount: () => get().items.reduce((sum, i) => sum + i.quantity, 0),
    }),
    { name: 'spicegarden-cart' }
  )
);
