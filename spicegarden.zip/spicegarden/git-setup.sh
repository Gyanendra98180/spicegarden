#!/bin/bash
# ============================================================
# Spice Garden — Git Setup Script
# GitHub username: Gyanendra98180
# ============================================================

echo "🍽  Setting up Spice Garden Git repository..."

# Initialize git
git init
git config user.name "Gyanendra98180"
git config user.email "Gyanendra98180@users.noreply.github.com"

# Create .gitignore
cat > .gitignore << 'EOF'
# Dependencies
node_modules/
.pnp
.pnp.js

# Next.js
frontend/.next/
frontend/out/
frontend/build/

# Environment files
.env
.env.local
.env.development.local
.env.test.local
.env.production.local
backend/.env
frontend/.env.local

# Logs
*.log
npm-debug.log*
yarn-debug.log*
yarn-error.log*

# OS
.DS_Store
Thumbs.db

# IDE
.vscode/
.idea/
*.swp
*.swo

# Docker volumes
postgres_data/

# Build outputs
dist/
build/
EOF

# Stage all files
git add .

# First commit
git commit -m "🎉 Initial commit — Spice Garden Restaurant App

Features:
- Next.js 14 frontend with TypeScript + Tailwind CSS
- Node.js + Express backend with Socket.io
- PostgreSQL database with full schema
- Razorpay payment integration (UPI, cards, wallets, COD)
- JWT auth with OTP (Twilio + Nodemailer)
- Real-time order tracking via Socket.io
- Firebase push notifications
- Admin panel with live dashboard
- Docker Compose for local dev
- Production Dockerfiles"

echo ""
echo "✅ Git repository initialized!"
echo ""
echo "Next steps to push to GitHub:"
echo ""
echo "  1. Create repo at: https://github.com/new"
echo "     Name it: spicegarden"
echo ""
echo "  2. Run these commands:"
echo "     git remote add origin https://github.com/Gyanendra98180/spicegarden.git"
echo "     git branch -M main"
echo "     git push -u origin main"
echo ""
echo "  Or with SSH:"
echo "     git remote add origin git@github.com:Gyanendra98180/spicegarden.git"
echo "     git branch -M main"
echo "     git push -u origin main"
